function getType(o) {
    return Object.prototype.toString.call(o).match(/^\[object\s(.*)\]$/)[1];
}
function isInstance(obj, type) {
    var ret = false,
        isTypeAString = getType(type) == "String",
        functionConstructor, i, l, typeArray, context;
    if (!isTypeAString && getType(type) != "Function") {
        throw new TypeError("type argument must be a string or function");
    }
    if (obj !== undefined && obj !== null && obj.constructor) {
        functionConstructor = obj.constructor;
        while (functionConstructor != functionConstructor.constructor) {
            functionConstructor = functionConstructor.constructor;
        }
        context = functionConstructor == Function ? self : functionConstructor("return window")();
        if (isTypeAString) {
            for (typeArray = type.split("."), i = 0, l = typeArray.length; i < l && context; i++) {
                context = context[typeArray[i]];
            }
        } else {
            context = type(context);
        }
        if (context) {
            ret = obj instanceof context;
            if (!ret && (type == "Number" || type == "String" || type == "Boolean")) {
                ret = obj.constructor == context
            }
        }
    }
    return ret;
}
var MasterModel = Backbone.RelationalModel.extend({
    getRelationshipObject:function (relationshipID, relationshipUUID, relationshipPropertyType) {
        if (typeof(relationshipPropertyType) === 'undefined') {
            relationshipPropertyType = "to_entity_uuid";
        }
        var relationshipsObj = this.get("relationships");
        var relationshipsArray = relationshipsObj.get("relationship");
        var filterByRelationshipID = _.filter(relationshipsArray, function (relationshipObj) {
            return relationshipObj.id === relationshipID;
        });
        if (typeof(filterByRelationshipID) === 'undefined') {
            return null;
        }
        var relationshipObj = _.find(filterByRelationshipID, function (relationshipObj) {
            return relationshipObj[relationshipPropertyType] === relationshipUUID;
        });
        if (typeof(relationshipObj) === 'undefined') {
            return null;
        } else {
            return relationshipObj;
        }
    },

    getModelObjectForUUID:function (objectUUID, modelObjectType, uuidType) {
        var modelObjInstance = this.get(modelObjectType);
        if (isInstance(modelObjInstance, "Backbone.Collection")) {
            var returnValue = modelObjInstance.find(function (modelObj) {
                return modelObj.get("uuid") === objectUUID;
            });
            if (typeof(returnValue) == "undefined") {
                return null;
            }
            return returnValue;
        }
        if (isInstance(modelObjInstance, "Backbone.Model")) {
            if (modelObjInstance.get("uuid") === objectUUID) {
                return modelObjInstance;
            }
            return null;
        }
        if (isInstance(modelObjInstance, "Array")) {
            var returnValue = _.find(modelObjInstance, function (modelObj) {
                return modelObj.get("uuid") === objectUUID;
            });
            if (typeof(returnValue) == "undefined") {
                return null;
            }
            return returnValue;
        }
    },
    toJSON:function () {
        if (this.extendedJSONData) {
            delete this.extendedJSONData;
        }
        this.extendedJSONData = {};
        var jsonData = Backbone.RelationalModel.prototype.toJSON.call(this);
        this.extendedJSONData = _.extend(jsonData, ModelHelper);
        return this.extendedJSONData;
    }

});

var ModelHelper = {
    getProperty:function (propertyName) {
        var pathExpression = "$..[*]." + propertyName;
        var result = jsonPath(this, pathExpression);
        return result;
    },
    setProperty:function (propertyName, value) {
        var pathExpression = "$..[*]." + propertyName;
        var pathString = jsonPath(this, pathExpression, {resultType:"PATH"});
        pathString = pathString[0].replace("$", "this");
        eval(pathString + "='" + value + "'");
    }
};
/**
 *
 */
var BDMModel = MasterModel.extend({

    idAttribute:'uuid',
    relations:[
        {
            type:Backbone.HasMany,
            key:'account',
            relatedModel:'AccountModel',
            reverseRelation:{
                key:'bdm',
                includeInJSON:'uuid'
            }
        },
        {
            type:Backbone.HasMany,
            key:'customer',
            relatedModel:'CustomerModel',
            reverseRelation:{
                key:'bdm',
                includeInJSON:'uuid'
            }
        },
        {
            type:Backbone.HasOne,
            key:'relationships',
            relatedModel:'RelationshipsModel',
            reverseRelation:{
                type:Backbone.HasOne,
                key:'bdm',
                includeInJSON:'uuid'
            }
        }
    ],
    initialize:function () {
    }

});

var CustomerModel = MasterModel.extend({
    relations:[
        {
            type:Backbone.HasOne,
            key:'alerts',
            relatedModel:'AlertsModel',
            reverseRelation:{
                key:'customer',
                includeInJSON:'uuid'
            }
        }
    ]
});

var AlertsModel = Backbone.RelationalModel.extend({
    relations:[
        {
            type:Backbone.HasMany,
            key:'alert',
            relatedModel:'AlertModel',
            reverseRelation:{
                key:'alerts',
                includeInJSON:'uuid'
            }
        }
    ]
});

var AlertModel = Backbone.RelationalModel.extend({

});
var AccountModel = Backbone.RelationalModel.extend({
    getCustomer:function (accountType) {
        var bdmModelObj = this.get("bdm");
        var relationshipObject = bdmModelObj.getRelationshipObject(accountType, this.get("uuid"), "from_entity_uuid");
        if (relationshipObject != null) {
            var customer = bdmModelObj.getModelObjectForUUID(relationshipObject.to_entity_uuid, "customer", "to_entity_uuid");
            return customer;
        }
    }
});

var RelationshipsModel = Backbone.RelationalModel.extend({
});
AccountModel.PRIMARY_ACCOUNT = "4";
AccountModel.SECONDARY_ACCOUNT = "6";


RelationshipsModel.FROM_UUID = "from_entity_uuid";
RelationshipsModel.TO_UUID = "to_entity_uuid";
RelationshipsModel.INTERMEDIATE_UUID = "intermediate_entity_uuid";