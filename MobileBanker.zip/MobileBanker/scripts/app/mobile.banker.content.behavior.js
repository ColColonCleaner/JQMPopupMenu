/**
 * Purpose -
 *     Visual Behavior of UI elements
 *     Assignment of Links and Button Functionality
 *     Active/Inactive state management
 * Application -
 *     Mobile Banker Web Application
 * @author e1049561
 * @author e1049545
 */
/**
 * Hides all of the tiles in the main window. This method is not currently used, but might be used in situations
 * where slider performance is an issue, or in situations where hiding all of the tiles from the user makes sense.
 */
function hideAllTiles() {
    $('#productOptions').hide();
    $('#customerTile .content-primary').hide();
    $('#needsProfileTile .content-primary').hide();
    $('#callNotesTile .content-primary').hide();
    $('#bankInfoTile .content-primary').hide();
    $('#assetsTile .content-primary').hide();
    $('#liabilitiesTile .content-primary').hide();
    $('#workItemsTile .content-primary').hide();
    $('#shoppingCartTile .content-primary').hide();
}

/**
 * Shows all of the tiles in the main window
 */
function showAllTiles() {
    $('#productOptions').show();
    $('#customerTile .content-primary').show();
    $('#needsProfileTile .content-primary').show();
    $('#callNotesTile .content-primary').show();
    $('#bankInfoTile .content-primary').show();
    $('#assetsTile .content-primary').show();
    $('#liabilitiesTile .content-primary').show();
    $('#workItemsTile .content-primary').show();
    $('#shoppingCartTile .content-primary').show();
}

/**
 * makes the main body of the page inactive
 * .inactive in main.css
 */
function makeInactive() {
    //add the inactive css class to the dashboard
    $('#dashboard').addClass("inactive");
    //block the slider holder
    $('#sliderHolder').block({ message:null });
    //change the inactive state variable
    inactive = true;
}

/**
 * makes the main body of the page active, if not already
 * removing .inactive class in main.css
 */
function makeActive() {
    //remove the inactive class from the dashboard
    $('#dashboard').removeClass("inactive");
    //unblock the slider holder
    $('#sliderHolder').unblock();
    //change the inactive state variable
    inactive = false;
}

/**
 * returns a boolean value as to whether the main dashboard is active or not
 * @returns boolean - whether the main page is active
 */
function contentPaneIsActive() {
    //return whether the dashboard is active
    return !($('#dashboard').hasClass("inactive"));
}

/**
 * Sets up events that are specific to the application dashboard
 */
function setupDashboardEvents() {

    //bind the main menu button with a popup menu
    $("#mainMenuButton").bind("click", function(){
        /**
         * A JSON object representing elements that should appear in the main menu
         */
        var mainMenuSettings = {
            //formatting for the popup menu
            formatting:{
                width:190,
                height:150,
                margins:3,
                optionsToDisplay:3
            },
            //function to call on open
            onOpen:function () {
                //alert("open");
            },
            //function to call on close
            onClose:function () {
                //alert("close");
            },
            //the function(s) to call along with specific button functionality
            baseFunction:function () {
                //Hello
            },
            //The css class that is to be assign to all list elements
            elementClass:"popupMenuButton",
            //list of elements in the popup menu
            elementList:[
                {
                    buttonID:"mainMenuSearchButton",
                    buttonText:"Customer Search",
                    buttonAction:function () {
                        //search button in the main menu, when clicked, the customer search dialog will be opened
                        $.mobile.changePage('#customerSearchDialog', {changeHash:'false', transition:'pop', role:'dialog', reverse:false});
                    }
                },
                {
                    buttonID:"mainMenuAddCustomerButton",
                    buttonText:"Add New Customer",
                    buttonAction:function (popupMenuOuter, popupMenuSettings) {
                        generateDialog(addNewCustomerDialogGenerationJSON);
                    }
                },
                {
                    buttonID:"mainMenuRemoveTileButton",
                    buttonText:($.appState.state.isPrivateMode)?("Exit Private Mode"):("Start Private Mode"),
                    buttonAction:function () {
                        $.appState.state.isPrivateMode = !$.appState.state.isPrivateMode;
                        updatePrivateMode();
                    }
                }
            ]
        };
        $("#mainMenuButton").createMenu(mainMenuSettings);
    });

    //bind mousedown events on page body
    $('body').bind('touchstart mousedown', function (evt) {
        //Nothing yet
    });

    //set up event to restart sliders when transitioning to the dashboard
    $(document).live("pagechange", function (e, data) {
        //get what the destination page ID is
        var toPageId = data.toPage.attr("id");
        //only perform the transition and formatting when moving to the dashboard from other windows
        if (toPageId == 'dashboard') {
            //run formatting on tiles, rather jumpy on screen
            formatAll();
            /*
             * Perform transition after 100ms
             * All timing here is for visual effect, not functionality.
             * Stops the user from seeing some formatting being performed on slider elements.
             */
            setTimeout(function () {
                //The sliderHolder has been hidden by router and is transitioned back to visible state
                $('#sliderHolder').fadeIn(1500);
                //calling format all again will properly format the inner tile areas.
                formatAll();
                //restart the sliders after browser regains control
                setTimeout(setupSliders, 0);
            }, 100);
        }
    });
}

/**
 * Applies all functionality to buttons on the dashboard and dialogs
 */
function applyButtonLinks() {
    $("#applyNewCustButton").unbind();
    $("#applyNewCustButton").click(function () {
        showPage("dashboard");
    });
    $("#businessNeedsAssessment").unbind();
    $('#businessNeedsAssessment').click(function () {
        generateDialog(businessProfileDialogGenerationJSON);
    });

    $("#addCallNotesButton").unbind();
    //add call notes button
    $("#addCallNotesButton").click(function () {
        $.mobile.changePage('#addCallRequestDialog', {changeHash:'false', transition:'pop', role:'dialog', reverse:false});
    });

    $("#businessProfileSubmitButton").unbind();
    //when the submit button on the business profile dialog is clicked, the dashboard is shown
    $("#businessProfileSubmitButton").click(function () {
        showPage("dashboard");
    });

    $("#enterAccountInformationNextButton").unbind();
    $('#enterAccountInformationNextButton').click(function () {
        $.mobile.changePage('#signFormDialog', {changeHash:'false', transition:'pop', reverse:false});
    });

    $("#signFormsNextButton").unbind();
    $('#signFormsNextButton').click(function () {
        $.mobile.changePage('#enterFullfillmentInformationDialog', {changeHash:'false', transition:'pop', reverse:false});
    });

    $("#applyFullfillmentInfoButton").unbind();
    //the final button in origination process before transitioning back to the dashboard
    $('#applyFullfillmentInfoButton').click(function () {
        showPage("dashboard");
    });

    $("#fundFullfillmentInfoButton").unbind();
    //fund button on the fullfillment dialog, currently set to just transition back to the dashboard
    $('#fundFullfillmentInfoButton').click(function () {
        showPage("dashboard");
    });

    $("#applyAddReferralButton").unbind();
    //apply button in the referral dialog, transitions to the dashboard
    $('#applyAddReferralButton').click(function () {
        showPage("dashboard");
    });
    //log that all button functionality has been applied
    if ($.debugModeActive)console.log("all button functionality applied");
}