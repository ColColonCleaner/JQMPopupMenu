/**
 * Purpose -
 *     Slider Management
 *     Slider Manipulation Event Assignments
 *     Position Marker Management
 * Application -
 *     Mobile Banker Web Application
 * @author e1049561
 * @author e1049545
 */

/**
 * Initializes the sliders in their respective containers with all presets
 */
function setupSliders() {
    //alert("starting sliders");
    if (!$.appState.state.slidersRunning) {
        $('#tileSlider_Top').iosSlider({
            snapToChildren:true,
            desktopClickDrag:true,
            //navSlideSelector: '#tileSlider_Top .slideSelectors .item',
            onSlideComplete:topSlideComplete,
            onSliderLoaded:topSliderLoaded,
            onSliderUpdate:topSliderUpdated,
            onSlideChange:topSlideChange,
            frictionCoefficient:'0.96',
            snapFrictionCoefficient:'0.96',
            elasticPullResistance:'.6'
        });
        $('#tileSlider_Bottom').iosSlider({
            snapToChildren:true,
            desktopClickDrag:true,
            onSlideComplete:bottomSlideComplete,
            onSliderLoaded:bottomSliderLoaded,
            onSliderUpdate:bottomSliderUpdated,
            onSlideChange:bottomSlideChange,
            frictionCoefficient:'0.96',
            snapFrictionCoefficient:'0.96',
            elasticPullResistance:'.6'
        });
        $.appState.state.slidersRunning = true;
        if ($.debugModeActive)console.log("sliders started/restarted");
    }
}

/**
 * destroys the sliders with no delay
 */
function destroySliders() {
    //only destroy the sliders if they are running
    if ($.appState.state.slidersRunning) {
        //destroy the top slider
        $('.tileSlider_Top').iosSlider('destroy');
        //destroy the bottom slider
        $('.tileSlider_Bottom').iosSlider('destroy');
        //update the state variable
        $.appState.state.slidersRunning = false;
    }
}

/**
 * Restarts the sliders using a delay of 200ms
 * Function ends immediately after assigning the timeouts
 */
function restartSliders() {
    //destroy the sliders
    setTimeout(function () {
        destroySliders();
    }, 0);
    //slight delay used (NECESSARY)
    //setup sliders
    setTimeout(function () {
        setupSliders();
    }, 200);
}

/**
 * Run once the top slider has been initialized
 * @param args - Array of settings passed from the slider instance
 */
function topSliderLoaded(args) {
    topSliderUpdated(args);
}
function bottomSliderLoaded(args) {
    bottomSliderUpdated(args);
}

function topSliderUpdated(args) {
    initSliderPositionMarkers(args, "topSliderBottom");
}
function bottomSliderUpdated(args) {
    initSliderPositionMarkers(args, "bottomSliderBottom");
}

/**
 * Called whenever a change in top slider's position occurs
 * @param args - Array of settings passed from the slider instance
 */
function topSlideChange(args) {
    //Update the location indication dots
    updatePositionMarkers(args, "topSliderBottom");
}
function bottomSlideChange(args) {
    //Update the location indication dots
    updatePositionMarkers(args, "bottomSliderBottom");
}

/**
 * This function will initialize the slider's position holder (circle display) based on the number of tiles in the slider.
 * @param targetDivID- The ID of the div in which the circles are to be placed.
 * @param args - slider arguments
 */
function initSliderPositionMarkers(args, targetDivID) {
    var tilesOnScreen = args.settings.slidesOnScreen;
    //set the target element that the position markers will be placed
    var targetDiv = $('#' + targetDivID);
    //clear out whatever was in there before
    targetDiv.empty();
    //since the markers are inline they will center when using text-align
    targetDiv.css('text-align', 'center');

    //Create markers and append them to the target element
    for (var circleIndex = 0, len = args.data.numberOfSlides, tos = tilesOnScreen; circleIndex < len; circleIndex++) {
        //create a span and apply the sliderCircles css class
        var circle = $('<span>').addClass("sliderCircles");
        //check if the current circle represents a Tile On Screen make it solid
        if (circleIndex < tos) {
            //use opacity 1 if the representing tile is on screen
            circle.css('opacity', 1);
        } else {
            //use opacity 0.3 if the representing tile is off screen
            circle.css('opacity', 0.3);
        }
        //set the id of the marker for future reference
        circle.attr('id', "circle" + targetDivID + circleIndex);
        //append the marker to the target element
        targetDiv.append(circle);
    }
    updatePositionMarkers(args, targetDivID)
}

/**
 * This function will modify the opacity of each of the markers and simulate the moving action from tile to tile
 * @param targetDivID - the div where the position holder lives
 * @param args - slider arguments
 */
function updatePositionMarkers(args, targetDivID) {
    var tilesOnScreen = args.settings.slidesOnScreen;
    //console.log("1:: C:"+args.currentSlideNumber+" N:"+args.data.numberOfSlides+" T:"+(args.currentSlideNumber+tilesOnScreen));
    //check to see if the position dots are over the edge. reposition accordingly.
    if ((args.currentSlideNumber + tilesOnScreen) > args.data.numberOfSlides) {
        args.currentSlideNumber = (args.data.numberOfSlides - tilesOnScreen);
    }
    //console.log("2:: C:"+args.currentSlideNumber+" N:"+args.data.numberOfSlides+" T:"+(args.currentSlideNumber+tilesOnScreen));

    //loop through markers from the first index up until slider's current position
    for (var i = 0, np = args.currentSlideNumber; i < np; i++) {
        //set all markers that are before the slider's current position to opacity 0.3
        $('#' + "circle" + targetDivID + i).css('opacity', 0.3);
    }
    //loop through markers from the sliders start position to its end position
    for (var j = 0, np2 = args.currentSlideNumber, tos = tilesOnScreen; j < tos; j++) {
        //set all markers that are part of the slider's current position to opacity 1
        $('#' + "circle" + targetDivID + (j + np2)).css('opacity', 1);
    }
    //loop through markers after the end of the slider to the end of the markers
    for (var k = 0, np3 = args.currentSlideNumber, tos = tilesOnScreen, tiles = args.data.numberOfSlides; k < args.data.numberOfSlides - tos - args.currentSlideNumber; k++) {
        //set all markers from the the first index after the slider up until the last marker to opacity 0.3
        $('#' + "circle" + targetDivID + (tos + args.currentSlideNumber + k)).css('opacity', .3);
    }
}

/**
 * Blocks the sliders from user input without making the app inactive
 * When the block is clicked, the sliders are unblocked, and the given function is called
 * @param - unblockFunction - The callback function that will be called when the sliders are unblocked
 */
function blockSliders(unblockFunction) {
    //assign the blocked element to a global variable so it can be referenced in unBlockSliders
    //Block the sliders
    sliderBlockedElement = $('#sliderHolder').block({
        message:null
    });
    //Bind press events to the block, when clicked unblock will be called in addition to the callback
    $('.blockUI').bind('touchstart mousedown', function (e) {
        unBlockSliders();
        unblockFunction();
    });
}

/**
 * Unblocks the sliders and cleans up the blocking process
 */
function unBlockSliders() {
    //use setTimout for browser control
    setTimeout(function () {
        //only do the following if the sliders are blocked
        if (sliderBlockedElement != null && sliderBlockedElement.data('blockUI.isBlocked')) {
            //unbind all mouse events from the blocker
            $('.blockUI').unbind('touchstart mousedown');
            //unblock the sliders
            sliderBlockedElement = $('#sliderHolder').unblock();
            //reset the slider blocked element
            sliderBlockedElement = null;
        }
    }, 0);
}

/**
 * Called after a slide on top slider is completed
 * @param args - Array of settings passed from the slider instance
 */
function topSlideComplete(args) {
    //Nothing yet
}
/**
 * Called after a slide on bottom slider is completed
 * @param args - Array of settings passed from the slider instance
 */
function bottomSlideComplete(args) {
    //Nothing yet
}