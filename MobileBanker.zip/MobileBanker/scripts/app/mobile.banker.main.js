/**
 * Purpose -
 *     Load Confirmation
 *     Application Startup
 *    Global Variable Storage
 * Application -
 *     Mobile Banker Web Application
 * @author e1049561
 * @author e1049545
 */

//On/off switch for debug mode
$.debugModeActive = true;

/**
 * Function that returns a GUID
 */
function GUID() {
    var S4 = function () {
        return Math.floor(
            Math.random() * 0x10000 /* 65536 */
        ).toString(16);
    };

    return (
        S4() + S4() + "-" +
            S4() + "-" +
            S4() + "-" +
            S4() + "-" +
            S4() + S4() + S4()
        );
}

/**
 * Gets the size of an object
 * @param obj
 * @return {Number}
 */
Object.size = function (obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};

/**
 * Increments the load index for the application
 * The load index is used to confirm all assets are loaded before continuing
 */
function incLoadIndex() {
    //only increment if the app is not fully loaded
    if (!$.appState.state.loaded) {
        //increment the app load index
        $.appState.state.appLoadIndex++;
    }
}

/**
 * Determines whether the application is completely loaded,
 * and takes appropriate action when it is.
 */
function tryInitialState() {
    //10*100ms on average for every resource load before timing out

    //Limit on timeout. Only for testing, cybercafe changes our IP addresses occasionally.
    //The IP/PORT being used is stored in the mobile.banker.data.ip.port.js file for each developer, and is unversioned.
    //Localhost/127.0.0.1 cannot be used when testing on the iPad.
    if ($.appState.state.attempts++ > (10 * $.appState.state.appGoalIndex)) {
        //Informative debug window. Displays when the application is unable to load all resources.
        alert("Never finished initializing. # resources loaded = " + $.appState.state.appLoadIndex + ". Wanting " + $.appState.state.appGoalIndex + ".");
        clearInterval($.appState.state.loadIntervalID);
    }
    //check if the application has reached or exceeded the load index
    if ($.appState.state.appLoadIndex >= $.appState.state.appGoalIndex) {
        //check if it has exceeded the load index and take appropriate action
        if ($.appState.state.appLoadIndex > $.appState.state.appGoalIndex) {
            alert("Load index was greater than expected. More functionality was added and not accounted for.");
            return;
        }
        //stop calling try
        clearInterval($.appState.state.loadIntervalID);
        //load the initial state
        loadInitialState();
        //reset the load index
        $.appState.state.appLoadIndex = 0;
        //change the global loaded boolean
        loaded = true;
    }
}

/**
 * Function that is run once the application is completely loaded
 */
function loadInitialState() {
    //setTimeout with time=0 fires once the browser regains control
    setTimeout(function () {
        //show the search dialog
        $.mobile.changePage('#customerSearchDialog', {transition:'pop', role:'dialog', reverse:true});
        //clear loading screen
        $.unblockUI();
        //perform initial formatting of UI elements
        initialFormat();
    }, 0);
}


/**
 * Called when the document is ready
 */
$(document).ready(function () {
    //Initialize the state model
    $.appState = new StateModel();

    //Hide the sliderHolder, it will be shown on dashboard transition
    $('#sliderHolder').hide();

    //show loading screen
    $.blockUI({message:"Loading Mobile Banker"});

    //load pages and dialogs into the DOM
    loadAll();

    //set when the program will reformat UI elements
    setupFormattingEvents();

    //set up the events that will fire on the dashboard
    setupDashboardEvents();

    //check every 100ms whether all resources are loaded
    $.appState.state.loadIntervalID = setInterval(tryInitialState, 100);
});

function displayDashboard() {
    //update the main header with the name of the customer
    var currentCustomerModel = $.appState.state.bdmModel.attributes.customerModel;
    var repositoryModel = currentCustomerModel.attributes['dataRepositoryModel'];
    var shortName = repositoryModel.account[0].account_info.nameAddress_info.short_name;
    $('#mainHeaderTitle').empty().html(shortName).css({"style":"line-height:44px;"});

    if ($.appState.state.showNeedsProfileTile && $.appState.tiles.needsProfileTileObj == null) {
        var needsProfileModel = new NeedsProfileModel();
        needsProfileModel.fetch();
        $.appState.tiles.needsProfileTileObj =
            new NeedsProfileTile({
                parentEL:$("#tileSlider_Bottom .slider"),
                model:needsProfileModel
            });
        $.appState.tiles.needsProfileTileObj.render();
    }

    if ($.appState.state.showCallNotesTile && $.appState.tiles.callNotesTileObj == null) {
        var callNotesModel = new CallNotesModel();
        callNotesModel.fetch();
        $.appState.tiles.callNotesTileObj =
            new CallNotesTile({
                parentEL:$("#tileSlider_Bottom .slider"),
                model:callNotesModel
            });
        $.appState.tiles.callNotesTileObj.render();
        //trigger create on the tile's jquery elements
        $.appState.tiles.callNotesTileObj.$el.trigger("create");
        //deal with the private mode case
        if($.appState.state.isPrivateMode){
            //init the removed tiles array if needed
            if($.appState.removedTiles == undefined)
            {
                $.appState.removedTiles = new Array();
            }
            //detach the tile from the page if private mode is on, and store in the array
            $.appState.removedTiles.push({
                'selector':"#" + $.appState.tiles.callNotesTileObj.model.attributes.ID,
                'slide':$.appState.tiles.callNotesTileObj.$el.detach()
                    .attr("style", "width: 0px; float: left;")
                    .data("firstAnimationDone", true),
                'sliderData':null
            });
        }
    }

    if ($.appState.state.showProductOptionsTile && $.appState.tiles.prodOptionsTileObj == null) {
        var productOptionsModel = new ProductOptionsModel();
        productOptionsModel.fetch();
        $.appState.tiles.prodOptionsTileObj =
            new ProductOptionsTile({
                parentEL:$("#tileSlider_Bottom .slider"),
                model:productOptionsModel
            });
        $.appState.tiles.prodOptionsTileObj.render();
    }

    if ($.appState.state.showBankInfoTile && $.appState.tiles.bankInfoTileObj == null) {
        var bankInfoModel = new BankInfoModel();
        bankInfoModel.fetch();
        $.appState.tiles.bankInfoTileObj =
            new BankInfoTile({
                parentEL:$("#tileSlider_Bottom .slider"),
                model:bankInfoModel
            });
        $.appState.tiles.bankInfoTileObj.render();
    }
    /**
     * Dynamically load the tiles based on the state model
     */
    if ($.appState.state.showCustomerTile) {
        if ($.appState.tiles.customerTileObj == null) {
            var customerTileModel = new CustomerTileModel();
            $.appState.tiles.customerTileObj =
                new CustomerTileView({
                    parentEL:$("#tileSlider_Top .slider"),
                    model:customerTileModel,
                    dataLinkModel:$.appState.state.bdmModel.get("customerModel")
                });
            $.appState.tiles.customerTileObj.render();
        } else {
            var newDataLinkModel = $.appState.state.bdmModel.get("customerModel");
            $.each($.appState.tiles.customerTileObj.tileContentModel.get("elements"), function(index, element){
                element.get("col2Model").set("dataLinkModel", newDataLinkModel);
            });
            //$.appState.tiles.customerTileObj.render();
        }
    }

    if ($.appState.state.showAssetsTile && $.appState.tiles.assetsTileObj == null) {
        $.appState.tiles.assetsTileObj = new AssetsInfoTile();
        $('#tileSlider_Top .slider').append($.appState.tiles.assetsTileObj.render().el);
    }

    if ($.appState.state.showLiabilitiesTile && $.appState.tiles.liabilitiesTileObj == null) {
        $.appState.tiles.liabilitiesTileObj = new LiabilitiesInfoTile();
        $('#tileSlider_Top .slider').append($.appState.tiles.liabilitiesTileObj.render().el);
    }

    if ($.appState.state.showWorkItemsTile && $.appState.tiles.workItemsTileObj == null) {
        $.appState.tiles.workItemsTileObj = new WorkItemsInfoTile();
        $('#tileSlider_Top .slider').append($.appState.tiles.workItemsTileObj.render().el);
    }

    //change page to the dashboard
    $.mobile.changePage('#dashboard', {changeHash:'false', transition:'pop', reverse:false});
}

function updatePrivateMode(){
    if($.appState.state.isPrivateMode){
        //Removal parameters that are sent to the slider removal function
        var removeParams = {
            //Selectors are sent to the selection function
            //Selectors are also used as hashes in the storage hash table for retrival
            selectors:[
                "#callNotesTile"
            ],
            //Slide electors are sent to this function and the slide element returned
            selectionFunction:function (slideRemovalSelector) {
                return $(slideRemovalSelector).parents('.sliderTile')[0];
            }
        };
        //remove the slide(s) and capture the code/bindings
        $('#tileSlider_Top').iosSlider('removeSlide', removeParams);
        //remove the slide(s) and capture the code/bindings
        $('#tileSlider_Bottom').iosSlider('removeSlide', removeParams);
    }else{
        var addParams = {
            selectors:[
                {
                    selector:"#callNotesTile",
                    index:2
                }
            ]
        };
        $('#tileSlider_Bottom').iosSlider('addSlide', addParams);
    }
}