/**
 * Purpose -
 *     Backbone Structure and Management
 *     Customer Information and Search Results Handling
 *     Managing all Data Models and Views
 * Application -
 *     Mobile Banker Web Application
 * @author e1049561
 * @author e1049545
 */

/**
 * Returns the type of any non-custom javascript object as a string.
 * This allows for parsing of models into custom form dialogs without knowing their format beforhand.
 * @param obj - an object to find the type of
 * @return - the type of the object passed in
 */
function get_type(thing) {
    if (thing === null)return "[object Null]"; // special case
    return Object.prototype.toString.call(thing);
}

/**
 * Defines the format that dates should be in as a standard for Mobile Banker
 * Converts input string to a formatted date
 * @param - formatString - String to be formatted as a date
 * @returns - formatString formatted as a date
 */
Date.prototype.customFormat = function (formatString) {
    var YYYY, YY, MMMM, MMM, MM, M, DDDD, DDD, DD, D, hhh, hh, h, mm, m, ss, s, ampm, AMPM, dMod, th;
    var dateObject = this;
    YY = ((YYYY = dateObject.getFullYear()) + "").slice(-2);
    MM = (M = dateObject.getMonth() + 1) < 10 ? ('0' + M) : M;
    MMM = (MMMM = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][M - 1]).substring(0, 3);
    DD = (D = dateObject.getDate()) < 10 ? ('0' + D) : D;
    DDD = (DDDD = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][dateObject.getDay()]).substring(0, 3);
    th = (D >= 10 && D <= 20) ? 'th' : ((dMod = D % 10) == 1) ? 'st' : (dMod == 2) ? 'nd' : (dMod == 3) ? 'rd' : 'th';
    formatString = formatString.replace("#YYYY#", YYYY).replace("#YY#", YY).replace("#MMMM#", MMMM).replace("#MMM#", MMM).replace("#MM#", MM).replace("#M#", M).replace("#DDDD#", DDDD).replace("#DDD#", DDD).replace("#DD#", DD).replace("#D#", D).replace("#th#", th);

    h = (hhh = dateObject.getHours());
    if (h == 0) h = 24;
    if (h > 12) h -= 12;
    hh = h < 10 ? ('0' + h) : h;
    AMPM = (ampm = hhh < 12 ? 'am' : 'pm').toUpperCase();
    mm = (m = dateObject.getMinutes()) < 10 ? ('0' + m) : m;
    ss = (s = dateObject.getSeconds()) < 10 ? ('0' + s) : s;
    return formatString.replace("#hhh#", hhh).replace("#hh#", hh).replace("#h#", h).replace("#mm#", mm).replace("#m#", m).replace("#ss#", ss).replace("#s#", s).replace("#ampm#", ampm).replace("#AMPM#", AMPM);
};

/**
 * Model that contains the current state of the application
 */
var StateModel = Backbone.Model.extend({
    setup:{
        desiredSlideWidth:300,
        //whether the bank uses sales management
        usesSalesManagement:true,
        //boolean - whether the browser supports orientation change
        supportsOrientationChange:"onorientationchange" in window,
        //The event to use based on whether the browser supports orientation change
        orientationEvent:("onorientationchange" in window) ? "orientationchange" : "resize"
    },
    state:{
        //This model represents the BDM model which will be passed to various dialogs
        bdmModel:null,
        //the current number of slides on screen
        slidesOnScreen:0,
        //Incremented every time a notable loading task is completed
        appLoadIndex:0,
        //The goal index that the program will load to
        appGoalIndex:2,
        //Attempts at reaching the application goal index
        attempts:0,
        //Whether the app's initial load has been completed
        loaded:false,
        //Whether a customer has been loaded yet
        firstCustomerLoaded:false,
        //Whether the dashboard is inactive
        inactive:false,
        //Whether the sliders are running
        slidersRunning:false,
        //The slider container in blocked/unblocked state (blockUI artifact)
        sliderBlockedElement:null,
        //Whether the app is in private mode
        isPrivateMode:false,
        //check interval variable
        loadIntervalID:null,
        showCustomerTile:true,
        showAssetsTile:true,
        showLiabilitiesTile:true,
        showWorkItemsTile:true,
        showNeedsProfileTile:true,
        showCallNotesTile:true,
        showProductOptionsTile:true,
        showShoppingCartTile:true,
        showBankInfoTile:true
    },
    tiles:{
        /**
         * Tiles are currently declared globally since they are originally added and initialized on document ready (to be changed to on user log in)
         * but rerendered on search from mobile.banker.data.backbone.js.
         */
        customerTileObj:null,
        assetsTileObj:null,
        liabilitiesTileObj:null,
        workItemsTileObj:null,
        needsProfTileObj:null,
        callNotesTileObj:null,
        prodOptionsTileObj:null,
        shoppingCartTileObj:null,
        bankInfoTileObj:null
    },
    initialize:function () {
        if ($.debugModeActive)console.log("State Model has been initialized");
    }
});
/**
 * The model for any label that is added to the interface.
 */
var LabelModel = Backbone.Model.extend({
    defaults:{
        labelText:"New Label:",
        dataLink:null,
        dataLinkModel:null
    },
    initialize:function () {
        if (this.attributes.dataLink != null && this.attributes.dataLinkModel != null) {
            //bind the updating
            _.bindAll(this, 'updateLabel');
            this.bind('change', this.updateLabel);
        }
        this.updateLabel();
    },
    updateLabel:function () {
        if (this.attributes.dataLink != null && this.attributes.dataLinkModel != null)
            this.attributes.labelText = _.template(this.attributes.dataLink)(this.attributes.dataLinkModel.toJSON());
        else
            console.log("no model used: " + this.attributes.labelText);
    }
});
/**
 * LabelModels are rendered with this view
 */
var LabelView = Backbone.View.extend({
    tagName:"label",
    className:"formLabels",
    defaults:{
        labelText:"defaultViewLabelText"
    },
    initialize:function () {
        //bind the rendering
        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    },
    render:function () {
        //clear all elements
        $(this.el).empty();
        $(this.el).append(this.model.attributes.labelText);
        var action = this.model.attributes.action;
        var model = this.model;
        $(this.el).bind('click', function () {
            action(this, model);
        });
        //return the element
        return this;
    }
});
/**
 * This model contains two sub-models, each representing their own label.
 */
var LabelModelPair = Backbone.Model.extend({
    dafults:{
        col1Model:null,
        col2Model:null
    },
    initialize:function () {
        this.attributes.col1Model.bind("change", function () {
            this.change();
        })
        this.attributes.col2Model.bind("change", function () {
            this.change();
        })
    }
});
/**
 * Renders a LabelModelPair, it will createa grid with
 * one rwo and two columns, placing the labels in each.
 */
var LabelPairView = Backbone.View.extend({
    tagName:"div",
    className:"ui-grid-a",
    defaults:{
        title:"default",
        data:"default",
        dataLink:"default",
        model:null
    },
    initialize:function () {
        this.col1Element = new LabelView({
            model:this.model.get("col1Model")
        })
        this.col2Element = new LabelView({
            model:this.model.get("col2Model")
        })
        this.render();
    },
    render:function () {
        //clear all elements
        $(this.el).empty();
        //create the two inner divs
        var col1 = $("<div class='ui-block-a'></div>").append(this.col1Element.render().el);
        var col2 = $("<div class='ui-block-b'></div>").append(this.col2Element.render().el);
        //append to the main element
        $(this.el).append(col1).append(col2);
    }
});
/**
 * A model that will contain a list of labelmodelpairs.
 */
var LabelPairListModel = Backbone.Model.extend({
    //defaults
    defaults:{
        elements:new Array()
    }
});
/**
 * Renders a labelpairlistmodel as an unordered list on screen.
 */
var LabelPairListView = Backbone.View.extend({
    //"<ul data-role='listview' class='tileListView' data-mini='true' data-theme='f'></ul>
    tagName:"ul",
    className:"tileListView",
    attributes:{
        "data-theme":"f",
        "data-role":"listview",
        "data-mini":"true"
    },
    //called on instantiation, creates the list elements and outer container
    initialize:function () {
        var tempViewArray = new Array();
        $.each(this.model.get("elements"),
            function (index, labelPairModel) {
                tempViewArray.push(new LabelPairView({model:labelPairModel}));
            });
        this.elementViews = tempViewArray;

        //bind the rendering
        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    },
    render:function () {
        $(this.el).empty();
        var tempEL = this.el;
        $.each(this.elementViews, function (index, view) {
            $(tempEL).append(view.el);
        });
        this.el = tempEL;
        return this;
    }
});
/**
 * The basic model for basic list elements
 */
var LIModel = Backbone.Model.extend({
    //default values if no options set
    defaults:{
        title:"New Product Option",
        action:function () {
            alert("no special functionality used")
        }
    }
});
/**
 * View for all basic list elements
 */
var LIView = Backbone.View.extend({
    tagName:"li",
    initialize:function () {
        //bind the rendering
        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    },
    render:function () {
        var textElement = $(".ui-link-inherit", $(this.el));
        //check to see if the element has already been populated
        if (textElement.length == 0) {
            //clear all elements
            $(this.el).empty();
            this.contentEL = $("<a href=''></a>");
            this.contentEL.unbind("click");
            //update and add elements back
            this.contentEL.append(this.model.get("title"));
            var action = this.model.get("action");
            var model = this.model;
            this.contentEL.bind('click', function () {
                action(this, model);
            });
            $(this.el).append(this.contentEL);
            var tempEl = $(this.el);
            setTimeout(function () {
                tempEl.trigger("create");
            }, 0);
        } else {
            textElement.html(this.model.get("title"));
            textElement.unbind("click");
            textElement.bind("click", this.model.get("action"));
        }
        //return the element
        return this;
    }
});
/**
 * Model for list items
 */
var ListModel = Backbone.Model.extend({
    //defaults
    defaults:{
        elements:new Array()
    }
});
var ListView = Backbone.View.extend({
    //"<ul data-role='listview' class='tileListView' data-mini='true' data-theme='f'></ul>
    tagName:"ul",
    className:"tileListView",
    attributes:{
        "data-theme":"f",
        "data-role":"listview",
        "data-mini":"true"
    },
    //called on instantiation, creates the list elements and outer container
    initialize:function () {
        var tempViewArray = new Array();
        $.each(this.model.get("elements"), function (index, listItemModel) {
            tempViewArray.push(new LIView({model:listItemModel}));
        });
        this.elementViews = tempViewArray;

        //bind the rendering
        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    },
    render:function () {
        $(this.el).empty();
        var tempEL = this.el;
        $.each(this.elementViews, function (index, view) {
            $(tempEL).append(view.render().el);
        });
        this.el = tempEL;
//        var tempEl = $(this.el);
//        setTimeout(function () {
//            tempEl.trigger("create");
//        }, 0);
        return this;
    }
});
/**
 * Model for collapisble lists. Any content may be added to the inside.
 */
var CollapsibleListModel = Backbone.Model.extend({
    //defaults
    defaults:{
        title:"default title",
        contents:null
    }
});
/**
 * View for all collapsible elements. Any content may be used in the content section.
 */
var CollapsibleListView = Backbone.View.extend({
    tagName:"div",
    attributes:{
        "data-theme":"f",
        "data-role":"collapsible",
        "data-inset":"false"
    },
    //called on instantiation, creates the list elements and outer container
    initialize:function () {
        this.headerEL = $("<h3></h3>");
        this.contentEL = $("<div data-theme='f' data-role='content'></div>");

        this.contentView =
            new ListView({
                model:this.model.get("contents")
            });
        //bind the rendering
        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    },
    render:function () {
        //clear out the main element
        $(this.el).empty().removeAttr("class");
        //reset the header and content elements
        this.headerEL = $("<h3></h3>");
        this.contentEL = $("<div data-theme='f' data-role='content'></div>");
        //update and re-add the header
        $(this.el).append(this.headerEL.append(this.model.get("title")));
        //clear the content outer and re-add the list
        this.contentEL.append(this.contentView.render().el);
        //add content outer to the main element
        $(this.el).append(this.contentEL);
//        var tempEl = $(this.el);
//        setTimeout(function () {
//            tempEl.trigger("create");
//        }, 0);
        return this;
    }
});
/**
 * Model for collapsible sets.
 */
var CollapsibleSetModel = Backbone.Model.extend({
    //defaults
    defaults:{
        elements:new Array()
    }
});
/**
 * A collapsible set is a list of collapsibles, in it's own container.
 */
var CollapsibleSetView = Backbone.View.extend({
    tagName:"div",
    attributes:{
        "data-role":"collapsible-set",
        "data-mini":"true",
        "data-inset":"false",
        "data-theme":"f"
    },
    initialize:function () {
        var cViews = new Array();
        $.each(this.model.get("elements"), function (index, collapsibleModel) {
            cViews.push(new CollapsibleListView({model:collapsibleModel}));
        });
        this.elementViews = cViews;

        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    },
    render:function () {
        //clear out the inner area
        $(this.el).empty();
        //capture scope
        var tempEL = this.el;
        $.each(this.elementViews, function (index, elementView) {
            //append it
            $(tempEL).append(elementView.render().el);
        });
        this.el = tempEL;
        var tempEl = $(this.el);
        setTimeout(function () {
            tempEl.trigger("create");
        }, 0);
        return this;
    }
});

/**
 * Tile Model. The base from which all backbonized tiles extend.
 * A tile model contains a header, contentarea, and a footer.
 */
var TileModel = Backbone.Model.extend({
    //used if no params given
    defaults:{
        ID:"NEWTILE",
        title:"New Tile Model"
    },
    //called on initialization
    //this should be implemented in the specific tile extension
    initialize:function () {

    },
    //sets the title for this collapsible
    setTitle:function (newTitle) {
        this.set("title", newTitle);
    }
});
/**
 * TILE CONTENT PARTS: TIlE HEADER
 * The tile header view allowes for a title, with additional content area provided.
 */
var TileHeaderView = Backbone.View.extend({
    tagName:"div",
    className:"tileHeader",
    defaults:{
        otherContent:null
    },
    initialize:function () {
        _.bindAll(this, 'render');
        if (this.model != null && typeof this.model != 'undefined') {
            this.model.bind('change', this.render);
        }
        if (this.otherContent != null && typeof this.otherContent != 'undefined') {
            this.otherContent.bind('change', this.render);
        }
    },
    //initializes the template for this view
    initializeTemplate:function () {
        //compile the template into an editable object
        this.template = _.template($(this.template).html());
    },
    render:function () {
        $(this.el).empty();
        var headerText = $("<h1>" + this.model.attributes.title + "</h1>");
        $(this.el).append(headerText);
        if (this.options.otherContent != null) {
            this.renderOtherContent(this.el);
        }
        return this;
    },
    renderOtherContent:function (element) {
        $(element).append(this.options.otherContent.render().el);
    }
});
/**
 * TILE CONTENT PARTS: Tile Content
 * This view contains the parts needed for tile content generation.
 * otherContent defines the view that will be rendered within the content area.
 */
var TileContentView = Backbone.View.extend({
    tagName:"div",
    attributes:{
        "data-theme":"f",
        "data-role":"content",
        "class":"tileContent"
    },
    defaults:{
        otherContent:null
    },
    initialize:function () {
        _.bindAll(this, 'render');
        if (this.model != null && typeof this.model != 'undefined') {
            this.model.bind('change', this.render);
        }
        if (this.otherContent != null && typeof this.otherContent != 'undefined') {
            this.otherContent.bind('change', this.render);
        }
    },
    render:function () {
        $(this.el).empty();
        if (this.model.hasFooter && !$(this.el).hasClass("hasFooter")) {
            $(this.el).addClass("hasFooter");
        }
        var contentPrimary = $("<div class='content-primary'></div>");
        $(this.el).append(contentPrimary);
        if (this.options.otherContent != null) {
            this.renderOtherContent(contentPrimary);
        }
        return this;
    },
    renderOtherContent:function (element) {
        $(element).append(this.options.otherContent.render().el);
    }
});
/**
 * TILE CONTENT PARTS: Tile Footer
 * This view contains the parts needed for tile footer generation.
 * otherContent defines the view that will be rendered within the footer area.
 */
var TileFooterView = Backbone.View.extend({
    tagName:"div",
    className:"tileFooter",
    defaults:{
        otherContent:null
    },
    initialize:function () {
        _.bindAll(this, 'render');
        if (this.model != null && typeof this.model != 'undefined') {
            this.model.bind('change', this.render);
        }
        if (this.otherContent != null && typeof this.otherContent != 'undefined') {
            this.otherContent.bind('change', this.render);
        }
    },
    render:function () {
        $(this.el).empty();
        if (this.options.otherContent != null) {
            this.renderOtherContent(this.el);
        }
        return this;
    },
    renderOtherContent:function (element) {
        $(element).append(this.options.otherContent.render().el);
    }
});
/**
 * The view that represents any backboneized tile.
 * Renders the internal header, content, and footer views.
 */
var TileView = Backbone.View.extend({
    //standard tile template
    template:"#tile-template",
    //which is a div element
    tagName:"div",
    //with class sliderTile
    className:"sliderTile",
    defaults:{
        tileHeaderView:null,
        tileContentView:null,
        tileFooterView:null
    },
    //called on instantiation, binds all modifications of this tile's model to the render function
    initialize:function () {
        this.initializeTemplate();
        if (this.tileHeaderView == null) {
            this.tileHeaderView =
                new TileHeaderView({
                    model:this.model,
                    otherContent:null
                });
        }
        if (this.tileContentView == null) {
            this.tileContentView =
                new TileHeaderView({
                    model:this.model,
                    tileHeaderContent:null
                });
        }
        //Footer optional so not dealt with

        //bind model changes to render
        _.bindAll(this, 'render');
        if (this.model != null && typeof this.model != 'undefined') {
            this.model.bind('change', this.render);
        }
    },
    //initializes the template for this view
    initializeTemplate:function () {
        //compile the template into an editable object
        this.template = _.template($(this.template).html());
    },

    //rendering functions
    render:function () {
        //generate the tile shell
        $(this.el).html(this.template({'tileID':this.model.get("ID")}));
        //find the inner block for content, headers, and footers
        var contentBlock = $("#" + this.model.attributes.ID, $(this.el));
        //make sure the contentBlock is empty
        contentBlock.empty();
        //update the tile contents
        this.renderTileArea(contentBlock);
        var elementCreate = this.$el;
        setTimeout(function () {
            elementCreate.trigger("create");
        }, 0);
        return this;
    },
    renderTileArea:function (element) {
        this.renderTileHeader(element);
        this.renderTileContent(element);
        this.renderTileFooter(element);
    },
    renderTileHeader:function (element) {
        $(element).append(this.tileHeaderView.render().el);
    },
    renderTileContent:function (element) {
        $(element).append(this.tileContentView.render().el);
    },
    renderTileFooter:function (element) {
        var footerView = this.tileFooterView;
        if (footerView != null)
            $(element).append(footerView.render().el);
    }
});

/**
 * SPECIFIC TILE SECTION
 */
/**
 * Model for the product options tile. extends standard tile model.
 * This is the collection of product options grabbed from the web service at the specified URL.
 */
var ProductOptionsModel = TileModel.extend({
    url:"/MobileBanker/MBA/selfService/getProductOptions/"
});
var ProductOptionsTile = TileView.extend({
    //called on instantiation, binds all modifications of this tile's model to the render function
    initialize:function () {
        var ID = "productOptionsTile";
        var title = "Product Options";

        if (this.model != null) {
            this.model.attributes.ID = ID;
            this.model.attributes.title = title;
        } else {
            this.model = new TileModel({
                ID:ID,
                title:title
            });
        }
        this.tileHeaderView =
            new TileHeaderView({
                model:this.model
            });

        var collapsibleModels = new Array();
        $.each(this.model.get("productOptionSets"), function (index, optionSet) {
            var optionModels = new Array();
            $.each(optionSet.elements, function (index, setElement) {
                var actionFunction = function (actionElement, actionModel) {
                    showActionMenu($(actionElement), setElement.type);
                }
                optionModels.push(
                    new LIModel({
                        title:setElement.title,
                        action:actionFunction
                    })
                );
            });
            var listModel = new ListModel({elements:optionModels});
            collapsibleModels.push(new CollapsibleListModel({
                title:optionSet.title,
                contents:listModel
            }))
        });
        var collapsibleSetModel = new CollapsibleSetModel({
            elements:collapsibleModels
        });
        this.tileContentModel = collapsibleSetModel;
        this.tileContentView =
            new TileContentView({
                model:this.model,
                otherContent:new CollapsibleSetView({
                    model:collapsibleSetModel
                })
            });
        this.tileFooterView = null;//no footer

        this.initializeTemplate();
        this.options.parentEL.append(this.render().el);

        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    }
});

/**
 * Model for the Bank Info tile. extends standard tile model.
 * This is the model for bank information
 */
var BankInfoModel = TileModel.extend({
    url:"/MobileBanker/MBA/selfService/getBankInfo/"
});
/**
 * This view composes the Bank Information Tile. This is essentially an outer shell that holds the Bank Information Content.
 */
var BankInfoTile = TileView.extend({
    //called on instantiation, binds all modifications of this tile's model to the render function
    initialize:function () {
        var ID = "bankInfoTile";
        var title = "Bank Info";

        if (this.model != null) {
            this.model.attributes.ID = ID;
            this.model.attributes.title = title;
        } else {
            this.model = new TileModel({
                ID:ID,
                title:title
            });
        }
        this.tileHeaderView =
            new TileHeaderView({
                model:this.model
            });

        var optionModels = new Array();
        $.each(this.model.attributes.listElements, function (index, bankInfoElement) {
            var actionFunction = function (actionElement, actionModel) {
                var triggerElement = $('<a id="optionElementLink" style="display: none" href="' + bankInfoElement.url + '" target="_blank">My link</a>');
                $("body").append(triggerElement);
                document.getElementById("optionElementLink").click();
                triggerElement.remove();
                //window.open(bankInfoElement.url,'_blank');
                //window.location.href = bankInfoElement.url;
            }
            optionModels.push(
                new LIModel({
                    title:bankInfoElement.title,
                    action:actionFunction
                })
            );
        });
        var listModel = new ListModel({elements:optionModels});

        this.tileContentModel = listModel;
        this.tileContentView =
            new TileContentView({
                model:this.model,
                otherContent:new ListView({
                    model:listModel
                })
            });
        this.tileFooterView = null;//no footer

        this.initializeTemplate();
        this.options.parentEL.append(this.render().el);

        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    }
});

/**
 * Model for the Call Notes tile. extends standard tile model.
 * This is the collection of Call Notes grabbed from the web service at the specified URL.
 */
var CallNotesModel = TileModel.extend({
    url:"/MobileBanker/MBA/selfService/getCallNotes/"
});
/**
 * This is the view for the Call notes tile, essentially is is just an outer shell that represents the tile itself.
 */
var CallNotesTile = TileView.extend({
    //called on instantiation, binds all modifications of this tile's model to the render function
    initialize:function () {
        var ID = "callNotesTile";
        var title = "Call Notes";
        /**
         * A JSON object representing elements that should appear in the call Notes Dialog
         */
        var callNotesDialogGenerationJSON = {
            id:"callNotesDialog",
            dialogName:"Call Notes",
            dialogType:"largeFormDialog",
            footerButtonAction:function () {
                showPage("dashboard");
            },
            formRows:[
                [
                    {
                        type:"Label",
                        dataID:"callTypeLabel",
                        data:"Call Type:"
                    },
                    {
                        type:"SelectBox",
                        dataID:"callType",
                        data:[
                            "Business Planning",
                            "Estate Planning",
                            "Financial Allocation",
                            "Gov Reg Review",
                            "Succession Planning"
                        ]
                    }
                ],
                [
                    {
                        type:"Label",
                        dataID:"followupDateLabel",
                        data:"Follow-Up Date:"
                    },
                    {
                        type:"DatePicker",
                        dataID:"followupDate",
                        data:null
                    }
                ],
                [
                    {
                        type:"Label",
                        dataID:"contactTypeLabel",
                        data:"Contact Type:"
                    },
                    {
                        type:"SelectBox",
                        dataID:"contactType",
                        data:[
                            "Branch Visit",
                            "eMail",
                            "Personal Visit",
                            "Phone Call",
                            "Video Conference"
                        ]
                    }
                ],
                [
                    {
                        type:"Label",
                        dataID:"subjectLabel",
                        data:"Subject:"
                    },
                    {
                        type:"TextField",
                        dataID:"subject",
                        data:null
                    }
                ],
                [
                    {
                        type:"Label",
                        dataID:"notesLabel",
                        data:"Notes:"
                    },
                    {
                        type:"TextArea",
                        dataID:"notes",
                        data:null
                    }
                ]
            ]
        };

        if (this.model != null) {
            this.model.attributes.ID = ID;
            this.model.attributes.title = title;
        } else {
            this.model = new TileModel({
                ID:ID,
                title:title
            });
        }

        this.tileHeaderView =
            new TileHeaderView({
                model:this.model
            });

        var optionModels = new Array();
        $.each(this.model.attributes.listElements, function (index, callNoteElement) {
            var actionFunction = function (actionElement, actionModel) {
                generateDialog(callNotesDialogGenerationJSON, actionModel);
            }
            optionModels.push(
                new LIModel({
                    title:callNoteElement.subject,
                    action:actionFunction
                })
            );
        });
        var listModel = new ListModel({elements:optionModels});

        this.tileContentModel = listModel;
        this.tileContentView =
            new TileContentView({
                model:this.model,
                otherContent:new ListView({
                    model:listModel
                })
            });
        this.tileFooterView = null;//no footer

        this.initializeTemplate();
        this.options.parentEL.append(this.render().el);

        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    }
});

/**
 * Model for the Needs Profile tile. extends standard tile model.
 * This is the model for the Needs Profile Tile
 */
var NeedsProfileModel = TileModel.extend({
    url:"/MobileBanker/MBA/selfService/getNeedsProfile/"
});
/**
 * This view composes the Needs Profile Tile
 */
var NeedsProfileTile = TileView.extend({
    //this function will initialize the tile itself
    initialize:function () {
        /**
         * A JSON object representing elements that should appear in the enter Account Info Dialog
         */
        var businessProfileDialogGenerationJSON = {
            id:"businessProfileDialog",
            dialogName:"Business Profile",
            dialogType:"smallFormDialog",
            footerButtonAction:function () {
                showPage('dashboard');
            },
            formRows:[
                [
                    {
                        type:"Label",
                        dataID:"compSponsoredInsLabel",
                        data:"Do you offer, or plan to offer company-sponsored insurance?"
                    },
                    {
                        type:"Slider",
                        dataID:"compSponsoredIns",
                        data:null
                    }
                ],
                [
                    {
                        type:"Label",
                        dataID:"e401kPlanLabel",
                        data:"Do you offer a 401k savings plan to your employees?"
                    },
                    {
                        type:"Slider",
                        dataID:"e401kPlan",
                        data:null
                    }
                ],
                [
                    {
                        type:"Label",
                        dataID:"numberOfLocationsLabel",
                        data:"How many locations does your business operate?"
                    },
                    {
                        type:"TextField",
                        dataID:"numberOfLocations",
                        data:null
                    }
                ]
            ]
        };
        var ID = "needsProfileTile";
        var title = "Needs Profile";

        if (this.model != null) {
            this.model.attributes.ID = ID;
            this.model.attributes.title = title;
        } else {
            this.model = new TileModel({
                ID:ID,
                title:title
            });
        }

        this.tileHeaderView =
            new TileHeaderView({
                model:this.model
            });

        var optionModels = new Array();
        $.each(this.model.attributes.listElements, function (index, needsProfileElement) {
            var dialogJSON = {};
            if (needsProfileElement.type == "businessNeedsAssessment") {
                dialogJSON = businessProfileDialogGenerationJSON;
            }
            var actionFunction = function (actionElement, actionModel) {
                generateDialog(dialogJSON, actionModel);
            }
            optionModels.push(
                new LIModel({
                    title:needsProfileElement.title,
                    action:actionFunction
                })
            );
        });
        var listModel = new ListModel({elements:optionModels});

        this.tileContentModel = listModel;
        this.tileContentView =
            new TileContentView({
                model:this.model,
                otherContent:new ListView({
                    model:listModel
                })
            });
        this.tileFooterView = null;//no footer

        this.initializeTemplate();
        this.options.parentEL.append(this.render().el);

        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    }
});

/**
 * Model for the Customer Info tile. extends standard tile model.
 * Contains the minimal information that each customer will have
 */
var CustomerTileModel = TileModel.extend({});
/**
 * This view composes the Needs Profile Tile
 */
var CustomerTileView = TileView.extend({
    //this function will initialize the tile itself
    initialize:function () {
        var ID = "customerInfoTile";
        var title = "Customer Info";
        var elements = [
            {
                labelText:"Customer Name:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%= dataRepositoryModel.account[0].account_info.nameAddress_info.short_name %>"
            },
            {
                labelText:"Customer Address:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%=dataRepositoryModel.account[0].account_info.nameAddress_info.name_address_line_7%>, <%=dataRepositoryModel.account[0].account_info.nameAddress_info.name_address_line_8%>"
            },
            {
                labelText:"Customer Email:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%=dataRepositoryModel.customer[0].emails.email_info[0].email_address %>"
            },
            {
                labelText:"Restriction:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"ThisThing"
            },
            {
                labelText:"Restriction:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"thisThing"
            },
            {
                labelText:"Tax ID:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%=dataRepositoryModel.account[0].account_info.tax_nbr%>"
            },
            {
                labelText:"Password Clue:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%=customerPasswdClue%>"
            },
            {
                labelText:"Maiden name:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%=customerMaidenName%>"
            },
            {
                labelText:"Birth Date:",
                dataLinkModel:this.options.dataLinkModel,
                dataLink:"<%=customerBirthDate%>"
            }
        ];

        if (this.model != null) {
            this.model.attributes.ID = ID;
            this.model.attributes.title = title;
        } else {
            this.model = new TileModel({
                ID:ID,
                title:title
            });
        }

        this.tileHeaderView =
            new TileHeaderView({
                model:this.model
            });

        var optionModels = new Array();
        $.each(elements, function (index, customerInfoElement) {
            var actionFunction = function () {
            }
            optionModels.push(
                new LabelModelPair({
                    col1Model:new LabelModel({
                        labelText:customerInfoElement.labelText,
                        dataLink:null,
                        dataLinkModel:null
                    }),
                    col2Model:new LabelModel({
                        labelText:customerInfoElement.dataLink,
                        dataLink:customerInfoElement.dataLink,
                        dataLinkModel:customerInfoElement.dataLinkModel
                    })
                })
            );
        });
        var listModel = new LabelPairListModel({elements:optionModels});

        this.tileContentModel = listModel;
        this.tileContentView =
            new TileContentView({
                model:this.model,
                otherContent:new LabelPairListView({
                    model:listModel
                })
            });
        this.tileFooterView = null;//no footer

        this.initializeTemplate();
        this.options.parentEL.append(this.render().el);

        _.bindAll(this, 'render');
        this.model.bind('change', this.render);
    }
});

/**
 * This is the view that controls search results
 */
var SearchResultLineItemView = Backbone.View.extend({
    template:"#searchResultLineItem-template",
    tagName:"div",
    className:"searchResultsInfo",
    //attributes are set up so that details collapse
    attributes:{
        "data-role":"collapsible",
        "data-inset":"false",
        "data-transition":"pop",
        "data-collapsed":"true",
        "data-iconpos":"right"
    },

    //display customer info if a data link click event fires
    events:{
        'mousedown .search_result_data_link':'openCustomer'
    },

    initialize:function () {
        //bind the render function to this view
        _.bindAll(this, 'render');
        //re-render the view when a change occurs
        this.model.bind('change', this.render);
        //lastly initialize the template
        this.initializeTemplate();
    },

    initializeTemplate:function () {
        //grab the html of the template and associate it with this view
        this.template = _.template($(this.template).html());
    },

    render:function () {
        //update the element's content associated with this view to that of the template itself.
        $(this.el).html(this.template(this.model.toJSON()));
        setTimeout(function () {
            $(this.el).trigger("expand");
        }, 2000);
        return this;
    },

    openCustomer:function (data) {
        //make a deep copy of the customer model to be passed into the bdm model
        var customerModelCopy = $.extend(true, {}, this.model);
        //reinitialize the BDM model
        $.appState.state.bdmModel = new Backbone.Model();
        //assign the master customer model to this line item's customer model
        $.appState.state.bdmModel.set({customerModel:customerModelCopy});
        //call show on the dashboard
        displayDashboard();
    }
});//end customer search info view

/**
 * This is the collection of customers grabbed from the web service at the specified URL.
 */
var CustomerCollection = Backbone.Collection.extend({
    initialize:function (models) {
        var queryString = $("#searchForm").serialize();
        if ($.debugModeActive)console.log(queryString);
        this.url = "/MobileBanker/MBA/selfService/searchCustByName/" + queryString;
    },
    model:CustomerModel
});

/**
 * This backbone view updates the search results dialog
 */
var CustomerSearchResultsView = Backbone.View.extend({
    initialize:function () {
        _.bindAll(this, 'render');
        this.template = _.template($('#customerSearchResultContainer-template').html());
        this.collection.bind('reset', this.render);
    },
    render:function () {
        if ($.debugModeActive)console.log("entering render of search results");
        var $searchResultsInfoEl,
            collection = this.collection;
        $(this.el).html(this.template({}));
        $searchResultsInfoEl = this.$(".searchResultsContainer");
        this.collection.each(function (customerModel) {
            var view = new SearchResultLineItemView({
                model:customerModel,
                collection:collection
            });
            $searchResultsInfoEl.append(view.render().el);
            $searchResultsInfoEl.trigger('create');
            if ($.debugModeActive)console.log($searchResultsInfoEl);
        });

        //TODO: format the data area of search results here

        //show the search results window
        $.mobile.changePage('#customerSearchResultsDialog', {changeHash:'false', transition:'pop', role:'dialog', reverse:true});

        return this;
    }
});

/**
 * This view represents the customer info tile
 */
//var CustomerInfoTile = Backbone.View.extend({
//
//    template:"#tile-template",
//    tagName:"div",
//    className:"sliderTile",
//    generalParams:{
//        tileID:"customerInfoTile",
//        tileTitle:"Customer Info"
//    },
//
//    //called on instantiation, binds all modifications of this tile's model to the render function
//    initialize:function () {
//        _.bindAll(this, 'render');
//        if (this.model != null && typeof this.model != 'undefined') {
//            this.model.bind('change', this.render);
//        }
//        this.initializeTemplate();
//    },
//
//    //initializes the template for this view
//    initializeTemplate:function () {
//        //compile the template into an editable object
//        this.template = _.template($(this.template).html());
//    },
//
//    render:function () {
//        //Make sure the model is not null and is not undefined
//        if (this.model != null && typeof this.model != 'undefined') {
//            //generate the html for the header
//            var headerContentParams = {};
//            var headerContentFunction = function () {
//                return "";
//            }
//            var headerParams = {
//                tileHeaderID:this.generalParams.tileID + "Header",
//                tileHeaderText:this.generalParams.tileTitle,
//                tileHeaderContent:headerContentFunction(headerContentParams)
//            };
//
//            //generate the html for the content area
//            var contentContentParams = this.model.toJSON();
//            var contentContentFunction = _.template($("#" + this.generalParams.tileID + "Content-template").html());
//            var contentParams = {
//                tileContentID:this.generalParams.tileID + "Content",
//                'hasFooter':this.hasFooter ? "hasFooter" : "",
//                tileContentContent:contentContentFunction(contentContentParams)
//            };
//
////            var footerContentParams = {}
////            var footerContentFunction = function (tileParams) {
////                return "";
////            }
////            var tileFooterJSON = {
////                tileFooterID:this.tileID + "Footer",
////                tileFooterContent:footerContentFunction(footerContentParams)
////            };
//            var footerParams = null;
//
//            //generation section
//            var tileHeaderHTML = _.template($("#tileHeader-template").html())(headerParams);
//            var tileContentHTML = _.template($("#tileContent-template").html())(contentParams);
//            var tileFooterHTML = "";
//            if (footerParams != null) {
//                tileFooterHTML = _.template($("#tileFooter-template").html())(footerParams);
//            }
//            $(this.el).html(this.template({
//                'tileID':this.generalParams.tileID,
//                'tileHeaderHTML':tileHeaderHTML,
//                'tileContentHTML':tileContentHTML,
//                'tileFooterHTML':tileFooterHTML
//            }));
//        }
//        return this;
//    }
//});

/**
 * This is the individual model for assets information
 */
var AssetsInfoModel = Backbone.Model.extend({

});

/**
 * This is the collection of assets grabbed from the web service at the specified URL.
 */
var AssetsInfoCollection = Backbone.Collection.extend({
    initialize:function (models) {
        this.url = "/MobileBanker/MBA/selfService/getAssetsInfo/";
    },
    model:AssetsInfoModel
});

/**
 * This view represents the assets information tile
 */
var AssetsInfoTile = Backbone.View.extend({
    template:"#assetsInfoTile-template",
    tagName:"div",

    initialize:function () {
        //we will need to bind events once we have information to even put in the assetsTile
        //      _.bindAll(this, 'render');
        //       this.model.bind('change', this.render);
        this.initializeTemplate();
    },

    initializeTemplate:function () {
        this.template = _.template($(this.template).html());
    },

    render:function () {
        //TODO: Create information for assets so that we can take in the tile information
        $(this.el).addClass("sliderTile").html(this.template());
        return this;
    }
});

/**
 * This view represents the liabilities information tile
 */
var LiabilitiesInfoTile = Backbone.View.extend({

    template:"#liabilitiesInfoTile-template",
    tagName:"div",

    initialize:function () {
        //we will need to bind events once we have information to even put in the assetsTile
        //      _.bindAll(this, 'render');
        //       this.model.bind('change', this.render);
        this.initializeTemplate();
    },

    initializeTemplate:function () {
        this.template = _.template($(this.template).html());
    },

    render:function () {
        //TODO: Create information for Liabilities so that we can take in the tile information
        $(this.el).addClass("sliderTile").html(this.template());
        return this;
    }
});

var WorkItemsModel = Backbone.Model.extend({

});

/**
 * This view represents the Work Items Information tile
 */
var WorkItemsInfoTile = Backbone.View.extend({

    template:"#workItemsInfoTile-template",
    tagName:"div",

    initialize:function () {
        //we will need to bind events once we have information to even put in the assetsTile
        //      _.bindAll(this, 'render');
        //       this.model.bind('change', this.render);
        this.initializeTemplate();
    },

    initializeTemplate:function () {
        this.template = _.template($(this.template).html());
    },

    render:function () {
        //TODO: Create information for Work Items so that we can take in the tile information
        $(this.el).addClass("sliderTile").html(this.template());
        return this;
    }
});

var ShoppingCartTile = Backbone.View.extend({

    template:"#shoppingCartTile-template",
    tagName:"div",

    initialize:function () {
        //we will need to bind events once we have information to even put in the assetsTile
        //      _.bindAll(this, 'render');
        //       this.model.bind('change', this.render);
        this.initializeTemplate();

        //add the slider tile class to this div (required for slider) then load the template
        $(this.el).addClass("sliderTile").html(this.template());
        //append the shell of this thing to the slider itself
        $("#tileSlider_Bottom .slider").append(this.el);
    },

    initializeTemplate:function () {
        this.template = _.template($(this.template).html());
    },

    render:function () {
        //find the content primary div from within the element
        var contPrimDiv = $(this.el).find('.content-primary');
        //actually create the div
        contPrimDiv.trigger('create');

        //return the tile view
        return this;
    }
});

/**
 * This backbone view is a generator for all two column form dialogs
 */
var formDialogView = Backbone.View.extend({
    tagName:"div",
    //className - sent in render
    //model - sent through constructor
    //dialogGenParams - sent through constructor

    attributes:{
        "data-role":"dialog"
        //ID sent through render
    },

    initialize:function () {
        if (this.model != undefined && this.model != null) {
            _.bindAll(this, 'render');
            //re-render the view when a change occurs
            this.model.bind('change', this.render);
        }
        this.template = _.template($("#formDialogView-template").html());
    },

    render:function (dialogGenParams) {
        //Convert the model to JSON
        //var modelElements = this.model.toJSON();
        if (dialogGenParams.formRows == undefined || dialogGenParams.formRows == null) {
            console.log("no form element object exists in dialog gen params, JSON object used is not a valid form dialog generation object, canceling operation.");
            return false;
        }
        //set up the form HTML string
        var formHTML = generateFormContents(dialogGenParams);
        //convert the blank template to html and fill the element
        $(this.el)
            //assign the dialog ID
            .attr('id', dialogGenParams.id)
            //assign the dialog type class
            .addClass(dialogGenParams.dialogType)
            //fill the inner html from the templateq
            .html(this.template({
            'dialogHeaderID':(dialogGenParams.id + "header"),
            'dialogTitleText':dialogGenParams.dialogName,
            'formDialogFooterButtonID':(dialogGenParams.id + "FooterButton"),
            'dialogContentArea':formHTML,
            'dialogFooterButtonText':"Apply"
        }));
        //Assign button events
        $("button", this.el);
        //bind the elements in the form to model values
        //assignValues(modelElements, dialogGenParams);

        //return the dialog
        return this;
    }
});

/**
 * This backbone view is a generator for all two column form dialogs
 */
var PDFDialogView = Backbone.View.extend({
    tagName:"div",
    //className - sent in render
    //model - sent through constructor
    //dialogGenParams - sent through constructor

    attributes:{
        "data-role":"dialog"
        //ID sent through render
    },

    initialize:function () {
        if (this.model != undefined && this.model != null) {
            _.bindAll(this, 'render');
            //re-render the view when a change occurs
            this.model.bind('change', this.render);
        }
        this.template = _.template($("#PDFDialogView-template").html());
    },

    render:function (dialogGenParams) {
        //Convert the model to JSON
        //var modelElements = this.model.toJSON();

        //set up the pdf element area
        //var pdfHTML = generatePDFContents(dialogGenParams);

        //convert the blank template to html and fill the element
        $(this.el)
            .attr('id', dialogGenParams.id)
            .addClass(dialogGenParams.dialogType)
            .html(this.template({
            'dialogHeaderID':(dialogGenParams.id + "header"),
            'dialogTitleText':dialogGenParams.dialogName,
            'formDialogFooterButtonID':(dialogGenParams.id + "FooterButton"),
            'dialogFooterButtonText':"Apply",
            'dialogContentArea':dialogGenParams.backgroundMessage
        }));

        //bind the elements in the form to model values
        //assignValues(modelElements, dialogGenParams);

        //return the dialog
        return this;
    }
});