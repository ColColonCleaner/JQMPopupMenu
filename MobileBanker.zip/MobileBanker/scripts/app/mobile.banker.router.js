
/**
 * This is the main controller that controls what happens when a JQuery event is called on any page or dialogs transition events
 */
var MainController = function(){

	/**
	 * Any functionality that should happen before the content page is shown should be placed in here
	 */
	this.showdashboard = function(){
		//Make the dashboard active
		makeActive();
	};//end showdashboard()

	this.closeSearchResultsDialog = function(){
        $('#customerSearchResultsDialog').remove();
        
	    loadDialog("pages/CustomerSearchResultsDialog.html");
	    
	    //force all listviews (unordered lists) within tiles to be initialized as listviews with JQuery UI Styling
        $('ul[data-role="listview"]').listview();
        $('ul[data-role="listview"]').listview('refresh');
        
        $('div[data-role="collapsible-set"]').collapsibleset();
        $('div[data-role="collapsible-set"]').collapsibleset('refresh');
	};
	/**
	 * Any functionality that should happen before the search dialog is shown should be placed in here
	 */
	this.showSearchDialog = function(){
		if($.debugModeActive)console.log("showing customer search window");
		makeInactive();

		//on submit, get the search results and show them in dialog
		$('#submitButton').click(function() {
			var customerSearchResultsObj = new CustomerCollection();
			customerSearchResultsObj.fetch({error: function(){alert("Search results could not be fetched\n");}});
			var customerSearchResultsViewObj = new CustomerSearchResultsView({collection: customerSearchResultsObj});
			
			//Empty the results container of whatever was there previously
			$('#searchResultsDataBody').empty();
			//Fill with new results into the container
			$('#searchResultsDataBody').append(customerSearchResultsViewObj.render().el);
			
			//collapsible is dynamically loaded
	        $('div[data-role="collapsible"]').collapsible();
	        
			return false;
		});

		$('#SelectedRadioName').bind( "change", function(event, ui) {
			if($.debugModeActive)console.log("Radio choice change fired");
			if ($('#SelectedRadioName').val() == 'Names') {
				$('#name').removeAttr('disabled').focus();
			} else {
				$('#account').attr('disabled', 'disabled');
			}
		});

		$('#SelectedRadioAccount').bind( "change", function(event, ui) {
			if ($('#SelectedRadioAccount').val() == 'Account') {
				$('#account').removeAttr('disabled').focus();
			} else {
				$('#name').attr('disabled', 'disabled');
			}
		});

		//Loads the search results when pressing the enter key (keycode 13)
		$('#customerSearchInputName').keypress(function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '13'){
				var customerSearchResultsObj = new CustomerCollection();
				customerSearchResultsObj.fetch();
				
				var customerSearchResultsViewObj = new CustomerSearchResultsView({collection: customerSearchResultsObj});
				//Empty the results container of whatever was there previously
				$('#searchResultsDataBody').empty();
				//Fill with new results into the container
				$('#searchResultsDataBody').append(customerSearchResultsViewObj.render().el);
				
				//collapsible is dynamically loaded
		        $('div[data-role="collapsible"]').collapsible();
			}
		});

		$('#searchDialogAccountInput').keypress(function(event){
			var keycode = (event.keyCode ? event.keyCode : event.which);
			if(keycode == '13'){
				var customerSearchResultsObj = new CustomerCollection();
				customerSearchResultsObj.fetch();
				var customerSearchResultsViewObj = new CustomerSearchResultsView({collection: customerSearchResultsObj});
				//Empty the results container of whatever was there previously
				$('#searchResultsDataBody').empty();
				//Fill with new results into the container
				$('#searchResultsDataBody').append(customerSearchResultsViewObj.render().el);
				//collapsible is dynamically loaded
		        $('div[data-role="collapsible"]').collapsible();
			}
		});

        setTimeout(function(){
            $('#customerSearchInputName').focus();
        },200);
	};//end showSearchDialog()


	/**
	 * Put any setup functionality that should happen before a business profile dialog is setup here
	 */
	this.showBusinessProfileDialog=function(){
		makeInactive();
	};//end showBusinessProfileDialog()

	/**
	 * Put any setup functionality that should happen before a call request dialog should be here
	 */
	this.showAddCallRequestDialog=function(){
		//apply button the button link for the button in call notes tile
		$("#applyAddCallReqButton").unbind();
		//when the apply button on the call requests dialog is clicked, the dashboard is shown
		$('#applyAddCallReqButton').click(function(){
			$.mobile.changePage('#dashboard', {changeHash:'false',transition:'pop', reverse: true});
		});
		makeInactive();
	};//end showAddCallRequestDialog()

	/**
	 * Any functionality that should happen before a new customer is created should be here
	 */
	this.showNewCustomerDialog=function(){
		makeInactive();
	};//end show new Customer Dialog()

	/**
	 * Any functionality that should happen before a enter customer information dialog opens should be placed here
	 */
	this.showEnterCustomerInfoDialog=function(){
		makeInactive();
		//We want to assign the next new customer click functionality when the page is shown.
		$('#nextNewCustButton').click(function(){
			$.mobile.changePage('#enterAccountInformationDialog', {changeHash:'false',transition:'pop', reverse: false});
		});
	};//end showEnterCustomerInfoDialog()
	
	/**
	 * Any functionality that should happen before an add referral dialog opens should be placed here
	 */
	this.showAddReferralDialog=function(){
		makeInactive();
	};

}; //end constructor for MainController();


/**
 * The router assigns the mainController's methods to the events of the individual dialogs and pages.
 */
new $.mobile.Router([
	                 { 	
	 //initialization events
	 "customerSearchDialog": { handler: 'showSearchDialog', events: "bs" },
	 "dashboard":{handler:'showdashboard',events:"bs"},
	 "businessProfileDialog":{handler:'showBusinessProfileDialog',events:"bs"},
	 "addCallRequestDialog":{handler:'showAddCallRequestDialog',events:'bs'},
	 "newCustomerDialog":{handler:'showNewCustomerDialog',events:'bs'},
	 "customerSearchResultsDialog":{handler:'closeSearchResultsDialog',events:'h'},
	 "enterCustomerInformationDialog":{handler:'showEnterCustomerInfoDialog',events:'bs'},
	 "addReferralDialog":{handler:'showAddReferralDialog',events:'bs'}
	                 }
], new MainController(), { ajaxApp: true });

function showPage(pageID){
    if(pageID=="dashboard"){
        $.mobile.changePage('#dashboard', {changeHash:'false', transition:'pop', reverse:true});
        makeActive();
    }
}
