/**
 * Purpose -
 *     Formatting of UI elements on Call
 *     Formatting of UI elements on Screen Orientation Change and Resize
 * Application -
 *     Mobile Banker Web Application
 * @author e1049561
 * @author e1049545
 */

/**
 * Variables for tile content heights, held as strings ending in "px"
 * Varies depending on whether the tile has a footer
 * Values are set on initialize and resize
 */
var tileContentPrimaryHeights = {
    //initial values are 40px. This is changed immediately on load.
    header:"40px",
    headerFooter:"40px"
};
var dialogContentPrimaryHeights = {
    header:"40px",
    footer:"40px"
};

/**
 * Sets up the application with proper event calls for resizing the UI
 */
function setupFormattingEvents() {
    //add listener to check for rotation or resize
    window.addEventListener($.appState.setup.orientationEvent, function () {
        //reformat everything
        formatAll();
        //if the browser supports orientation change, restart the sliders on rotate.
        if ($.appState.setup.supportsOrientationChange) {
            //restartSliders();
        }
    }, false);

    $(window).bind('pageChange', function (evt) {
        if ($.debugModeActive)console.log($(evt.target).id);
    });
}

/**
 * properly formats all items properly on screen
 */
function formatAll() {
    //format the sliders
    formatSliderHolder();
    //Format tile content panes
    formatTileContent();
    //Others added as needed
}

/**
 * Initial formatting that is performed on the application during load
 */
function initialFormat() {
    //format the sliders
    formatSliderHolder();
    //Format tile content panes
    formatTileContent();

    //apply all links and functionality
    applyButtonLinks();

    //increment the load index for this function
    incLoadIndex();
}

/**
 * Formats the size of the slider holder to fill the correct content area
 */
function formatSliderHolder() {
    //document height and width
    var documentHeight = $(window).height();
    var documentWidth = $(window).width();

    //format the slider holder
    var headerHeight = $('#mainHeader').height();
    //the height of the slider holder is the document height minus the header height
    var sliderHolderHeight = (documentHeight - headerHeight);
    //convert the slider holder height to a string for assignment
    var sliderHolderHeightStr = sliderHolderHeight + "px";
    //convert the document width to a string for assignment
    var documentWidthStr = documentWidth + "px";
    //assign css to the slider holder
    $('#sliderHolder').css({
        "height":sliderHolderHeightStr,
        "width":documentWidthStr
    });

    //the height for each of the two sliders should be half of the total vertical space - 40px for spacing
    var classSliderHolderHeightStr = ((sliderHolderHeight / 2) - 40) + "px";
    //Note using class not ID below. ID siderHolder contains both sliders.
    //SliderHolder class is assigned to each of the two slider's outer divs.
    $('.sliderHolder').css({
        "height":classSliderHolderHeightStr
    });
}

/**
 * Formats the content portion of every tile
 * Currently only modifying height
 */
function formatTileContent() {
    //calculate the content heights of all tiles without footers
    calcTileContentHeight();
    //calculate the content heights of all tiles with footers
    calcFooterTileContentHeight();

    //find all of the elements that are tileContent and iterate
    $('.tileContent').each(function (i, obj) {
        //check if the element has the footer class attached
        if ($(this).hasClass('hasFooter')) {
            //use the height with footer
            $(this).css('height', tileContentPrimaryHeights.headerFooter);
        }
        else {
            //use the non-footer height
            $(this).css('height', tileContentPrimaryHeights.header);
        }
    });
}

/**
 * Returns the style found using the given selector.
 * @param selectorString - String name of the desired style rule.
 * @return - The style selected using the string selector.
 */
function getCSSRule(selectorString) {
    var styles = document.styleSheets;
    for (var i = 0, len = styles.length; i < len; i++) {
        var sheet = styles[i];
        var rules = sheet.cssRules;
        for (var j = 0, len2 = rules.length; j < len; j++) {
            var rule = rules[j];
            if (rule && rule.selectorText && rule.selectorText.indexOf(selectorString) !== -1) {
                return rule.style;
            }
        }
    }
}

/**
 * Calculates the height of the content-primary section of tiles that DO NOT have footers
 */
function calcTileContentHeight() {
    //Use the customer tile for calculations, since it will 'always' be present regardless of customer preference
    var tileHeaderHeight = 40;
    var tileHeight = $($('.sliderHolder')[0]).height();
    var contentHeight = (tileHeight - tileHeaderHeight) + "px";
    tileContentPrimaryHeights.header = contentHeight;
}

/**
 * Calculates the height of the content-primary section of tiles that have footers
 */
function calcFooterTileContentHeight() {
    //Use the customer tile for calculations, since it will 'always' be present regardless of customer preference
    var tileHeaderHeight = 40;
    var tileHeight = $($('.sliderHolder')[0]).height();
    var contentHeight = (tileHeight - (tileHeaderHeight * 2)) + "px";
    tileContentPrimaryHeights.headerFooter = contentHeight;
    //Assumes that all tile footers are the same height as headers
}