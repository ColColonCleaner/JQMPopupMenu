/**
 * A JSON object representing elements that should appear in the add Referral Dialog
 */
var addReferralDialogGenerationJSON = {
    id:"addReferralDialog",
    dialogName:"Add Referral Dialog",
    dialogType:"largeFormDialog",
    footerButtonAction:function () {
        showPage("dashboard");
    },
    formRows:[
        [
            {
                type:"Label",
                dataID:"referralProductLabel",
                data:"Product:"
            },
            {
                type:"Label",
                dataID:"referralProduct",
                data:"Checking"
            }
        ],
        [
            {
                type:"Label",
                dataID:"referralAssignToLabel",
                data:"Assign to:"
            },
            {
                type:"SelectBox",
                dataID:"referralAssignTo",
                data:[
                    "Powers, Nancy",
                    "Owens, Sam",
                    "Rupen, Art",
                    "Stevens, Ian",
                    "Taylor, Mary"
                ]
            }
        ],
        [
            {
                type:"Label",
                dataID:"referralFollowUpLabel",
                data:"Follow-up:"
            },
            {
                type:"DatePicker",
                dataID:"referralFollowUp",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"referralNotesLabel",
                data:"Notes:"
            },
            {
                type:"TextArea",
                dataID:"referralNotes",
                data:null
            }
        ]
    ]
}

/**
 * A JSON object representing elements that should appear in the add New Customer Dialog
 */
var addNewCustomerDialogGenerationJSON = {
    id:"newCustomerDialog",
    dialogName:"Add New Customer",
    dialogType:"largeFormDialog",
    footerButtonAction:function () {
        showPage("dashboard");
    },
    formRows:[
        [
            {
                type:"Label",
                dataID:"customerNameLabel",
                data:"Name:"
            },
            {
                type:"TextField",
                dataID:"customerName",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerAddressLabel",
                data:"Address:"
            },
            {
                type:"TextField",
                dataID:"customerAddress",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerAdditionalAddressLabel",
                data:"Additional Address:"
            },
            {
                type:"TextField",
                dataID:"customerAdditionalAddress",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerCityStateZipLabel",
                data:"City/State/Zip:"
            },
            {
                type:"TextField",
                dataID:"customerCityStateZip",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerEmail1Label",
                data:[
                    "Personal Email",
                    "Business Email"
                ]
            },
            {
                type:"TextField",
                dataID:"customerEmail1",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerEmail2Label",
                data:[
                    "Personal Email",
                    "Business Email"
                ]
            },
            {
                type:"TextField",
                dataID:"customerEmail2",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerPhone1Label",
                data:[
                    "Mobile Phone",
                    "Home Phone"
                ]
            },
            {
                type:"TextField",
                dataID:"customerPhone1",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerPhone2Label",
                data:[
                    "Mobile Phone",
                    "Home Phone"
                ]
            },
            {
                type:"TextField",
                dataID:"customerPhone2",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerRestrictionLabel",
                data:"Restriction:"
            },
            {
                type:"SelectBox",
                dataID:"customerRestriction",
                data:[
                    "No Restriction"
                ]
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerSolicitLabel",
                data:"Solicit:"
            },
            {
                type:"TextField",
                dataID:"customerSolicit",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerHousingStatusLabel",
                data:"Own / Rent:"
            },
            {
                type:"SelectBox",
                dataID:"customerHousingStatus",
                data:[
                    "Own Duplex",
                    "Own Single-Family Home",
                    "Rent Single-Family Home",
                    "Rent One-Bed Apartment",
                    "Rent Two-Bed Apartment"
                ]
            }
        ]
    ]
}

/**
 * A JSON object representing elements that should appear in the enter Customer Info Dialog
 */
var enterCustomerInfoDialogGenerationJSON = {
    id:"enterCustomerInformationDialog",
    dialogName:"Enter Customer Information",
    dialogType:"largeFormDialog",
    footerButtonAction:function () {
        generateDialog(enterAccountInfoDialogGenerationJSON);
    },
    formRows:[
        [
            {
                type:"Label",
                dataID:"customerNameLabel",
                data:"Name:"
            },
            {
                type:"TextField",
                dataID:"customerName",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerAddressLabel",
                data:"Address:"
            },
            {
                type:"TextField",
                dataID:"customerAddress",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerAdditionalAddressLabel",
                data:"Additional Address:"
            },
            {
                type:"TextField",
                dataID:"customerAdditionalAddress",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerCityStateZipLabel",
                data:"City/State/Zip:"
            },
            {
                type:"TextField",
                dataID:"customerCityStateZip",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerEmail1Label",
                data:[
                    "Personal Email",
                    "Business Email"
                ]
            },
            {
                type:"TextField",
                dataID:"customerEmail1",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerEmail2Label",
                data:[
                    "Personal Email",
                    "Business Email"
                ]
            },
            {
                type:"TextField",
                dataID:"customerEmail2",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerPhone1Label",
                data:[
                    "Mobile Phone",
                    "Home Phone"
                ]
            },
            {
                type:"TextField",
                dataID:"customerPhone1",
                data:null
            }
        ],
        [
            {
                type:"SelectBox",
                dataID:"customerPhone2Label",
                data:[
                    "Mobile Phone",
                    "Home Phone"
                ]
            },
            {
                type:"TextField",
                dataID:"customerPhone2",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerRestrictionLabel",
                data:"Restriction:"
            },
            {
                type:"SelectBox",
                dataID:"customerRestriction",
                data:[
                    "No Restriction"
                ]
            }
        ],
        [
            {
                type:"Label",
                dataID:"customerSolicitLabel",
                data:"Solicit:"
            },
            {
                type:"TextField",
                dataID:"customerSolicit",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"taxIDLabel",
                data:"Tax ID:"
            },
            {
                type:"SelectBox",
                dataID:"taxIDType",
                data:[
                    "None",
                    "Employee Number",
                    "Individual Tax ID (TIDN)",
                    "Social Security"
                ]
            },
            {
                type:"TextField",
                dataID:"taxID",
                data:null
            }
        ]
    ]
}

/**
 * A JSON object representing elements that should appear in the enter Account Info Dialog
 */
var enterAccountInfoDialogGenerationJSON = {
    id:"enterAccountInformationDialog",
    dialogName:"Enter Account Information",
    dialogType:"largeFormDialog",
    footerButtonAction:function () {
        generateDialog(signFormDialogGenerationJSON);
    },
    formRows:[
        [
            {
                type:"Label",
                dataID:"openingDepositLabel",
                data:"Opening deposit:"
            },
            {
                type:"TextField",
                dataID:"openingDeposit",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"fundingMethodLabel",
                data:"Funding Method:"
            },
            {
                type:"SelectBox",
                dataID:"fundingMethod",
                data:[
                    "Mountains of Gold Coins",
                    "Herbs and Tonics"
                ]
            }
        ],
        [
            {
                type:"Label",
                dataID:"alternativeAddressLabel",
                data:"Alternative address:"
            },
            {
                type:"Slider",
                dataID:"alternativeAddress",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"onlineBankingLabel",
                data:"Online Banking:"
            },
            {
                type:"Slider",
                dataID:"onlineBanking",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"starterChecksLabel",
                data:"Starter Checks:"
            },
            {
                type:"Slider",
                dataID:"starterChecks",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"electronicStatementsLabel",
                data:"Electronic Statements:"
            },
            {
                type:"Slider",
                dataID:"electronicStatements",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"combinedStatementsLabel",
                data:"Combined Statements:"
            },
            {
                type:"Slider",
                dataID:"combinedStatements",
                data:null
            }
        ],
        [
            {
                type:"Label",
                dataID:"directDepositLabel",
                data:"Direct Deposit:"
            },
            {
                type:"Slider",
                dataID:"directDeposit",
                data:null
            }
        ]
    ]
};

/**
 * A JSON object representing elements that should appear in the sign Form Dialog
 */
var signFormDialogGenerationJSON = {
    id:"signFormDialog",
    dialogName:"Sign Forms",
    dialogType:"pdfDialog",
    footerButtonAction:function () {
        generateDialog(enterFulfillmentInfoDialogGenerationJSON);
    },
    pdf:null,
    backgroundMessage:"PDF WILL BE HERE"
};

/**
 * A JSON object representing elements that should appear in the enter Fulfillment Info Dialog
 */
var enterFulfillmentInfoDialogGenerationJSON = {
    id:"enterFulfillmentInformationDialog",
    dialogName:"Enter Fulfillment Information",
    dialogType:"largeFormDialog",
    footerButtonAction:function () {
        showPage("dashboard");
    },
    formRows:[
        [
            {
                type:"Label",
                dataID:"fundingMethodLabel",
                data:"Funding Method:"
            },
            {
                type:"Label",
                dataID:"fundingMethod",
                data:"External Transfer"
            }
        ],
        [
            {
                type:"Label",
                dataID:"initialDepositLabel",
                data:"Initial Deposit:"
            },
            {
                type:"Label",
                dataID:"initialDeposit",
                data:"$400.00"
            }
        ],
        [
            {
                type:"Button",
                dataID:"fundAccountButton",
                buttonText:"Fund Account"
            },
            {
                type:"Label",
                dataID:"blarg",
                data:""
            }
        ],
        [
            {
                type:"Label",
                dataID:"fulfillmentNotesLabel",
                data:"Notes:"
            },
            {
                type:"TextArea",
                dataID:"fulfillmentNotes",
                data:"",
                validation:"required, date"

            }
        ]
    ]
};

function generateDialog(dialogGenerationJSON, backboneModel) {
    //create variable to store the dialog view
    var genDialogView = null;
    //Use a different view for different types of dialogs
    if (dialogGenerationJSON.dialogType == "largeFormDialog"
        || dialogGenerationJSON.dialogType == "smallFormDialog") {
        //create the form dialog view
        genDialogView = new formDialogView({model:backboneModel});
    } else if (dialogGenerationJSON.dialogType == "pdfDialog") {
        //create the form dialog view
        genDialogView = new PDFDialogView({model:backboneModel});
    } else {
        console.log("Dialog to generate was of an invalid type.")
    }
    //first check to see if there isn't an instance of call notes dialog already in the DOM
    if ($("#" + dialogGenerationJSON.id).length == 0) {
        //append the dialog's html to the document
        $('body').append(genDialogView.render(dialogGenerationJSON).el);
    } else {
        //if there was an instance of this already, we replace the old one iwth the new one
        $("#" + dialogGenerationJSON.id).replaceWith(genDialogView.render(dialogGenerationJSON).el);
    }
    //assign the footer button action if there is one
    var footerButton = $(".footerButton", "#" + dialogGenerationJSON.id);
    if (footerButton.length > 0) {
        footerButton.click(dialogGenerationJSON.footerButtonAction);
    }
    //make the page inactive
    makeInactive();
    //change page to the dialog
    $.mobile.changePage("#" + dialogGenerationJSON.id, {changeHash:'false', transition:'pop'});
}

/**
 * Returns a generated list of items
 * @param listGenParams
 */
function generateMenuListContents(listGenParams) {
    console.log(listGenParams);
    return false;
}

/**
 * Generates the content HTML of a form, based on specific dialog generation parameters
 * @param dialogGenParams - Setting which which to generate the form
 * @return {String} - form HTML content as a string
 */
function generateFormContents(dialogGenParams) {
    var formHTML = "";
    //Loop through all rows in the gen params
    $.each(dialogGenParams.formRows, function (rowIndex, rowElements) {
        //use the number of elements in each row to decide which template to use
        var rowElementCount = Object.size(rowElements);
        //loop through all elements in this row
        switch (rowElementCount) {
            case 0:
                console.log("rowElements had no elements, exiting function");
                return;
                break;
            case 1:
                console.log("not allowing single elements in a form row");
                return;
                break;
            case 2:
                //get the compiled template for this form row
                var rowTemplateFunction = _.template($("#formDialogRow-2col-template").html());
                var rowTemplateHTML = rowTemplateFunction({
                    'dialogTitleText':dialogGenParams.id,
                    'formDialogRowIndex':rowIndex,
                    'formDialogRowElement0':getRowElementHTML(rowElements[0]),
                    'formDialogRowElement1':getRowElementHTML(rowElements[1])
                });
                formHTML += rowTemplateHTML;
                break;
            case 3:
                //get the compiled template for this form row
                var rowTemplateFunction = _.template($("#formDialogRow-3col-template").html());
                var rowTemplateHTML = rowTemplateFunction({
                    'dialogTitleText':dialogGenParams.id,
                    'formDialogRowIndex':rowIndex,
                    'formDialogRowElement0':getRowElementHTML(rowElements[0]),
                    'formDialogRowElement1':getRowElementHTML(rowElements[1]),
                    'formDialogRowElement2':getRowElementHTML(rowElements[2])
                });
                formHTML += rowTemplateHTML;
                break;
            case 4:
                //get the compiled template for this form row
                var rowTemplateFunction = _.template($("#formDialogRow-4col-template").html());
                var rowTemplateHTML = rowTemplateFunction({
                    'dialogTitleText':dialogGenParams.id,
                    'formDialogRowIndex':rowIndex,
                    'formDialogRowElement0':getRowElementHTML(rowElements[0]),
                    'formDialogRowElement1':getRowElementHTML(rowElements[1]),
                    'formDialogRowElement2':getRowElementHTML(rowElements[2]),
                    'formDialogRowElement3':getRowElementHTML(rowElements[3])
                });
                formHTML += rowTemplateHTML;
                break;

        }
        $.each(rowElements, function (elementIndex, rowElement) {

        });
    });
    return formHTML;
}

/**
 * Returns the HTML for this row element as a string
 * @param element - the element to create
 */
function getRowElementHTML(element) {
    //form element row html variable
    var rowElementHTML = "REPLACE";
    //function to generate reach row element from template
    var rowElementTemplateFunction = null;
    //HTML for the created row element
    var rowElementHTML = null;
    //detect which type of form element is needed for this row
    if (element.type == "SelectBox") {//generation options for selectBox
        var rowElementOptionsHTML = "";
        $.each(element.data, function (index, element) {
            //get the compiled template for this select box's options
            var rowElementOptionsTemplateFunction = _.template($("#formDialogRowSelectItem-template").html());
            rowElementOptionsHTML += rowElementOptionsTemplateFunction({
                'optionText':element
            });
        });
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowSelect-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'fieldID':(element.dataID),
            'selectBoxOptions':rowElementOptionsHTML
        });
    } else if (element.type == "DatePicker") {//generation options for datePicker
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowDatePicker-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'fieldID':(element.dataID)
        });
    } else if (element.type == "TextField") {//generation options for text fields
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowTextField-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'fieldID':(element.dataID)
        });
    } else if (element.type == "Label") {//generation options for text fields
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowLabel-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'formDialogRowLabelText':element.data,
            'fieldID':(element.dataID)
        });
    } else if (element.type == "TextArea") {//generation options for text areas
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowTextArea-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'fieldID':(element.dataID)
        });
    } else if (element.type == "Slider") {//generation options for text areas
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowSlider-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'fieldID':(element.dataID)
        });
    } else if (element.type == "Button") {//generation options for text areas
        //get the compiled template for this form row element
        rowElementTemplateFunction = _.template($("#formDialogRowButton-template").html());
        rowElementHTML = rowElementTemplateFunction({
            'fieldID':(element.dataID),
            'buttonText':element.buttonText
        });
    }
    //return the HTML
    return rowElementHTML;
}

/**
 * Generator for elements that should appear in the action menu
 */
function showActionMenu(hoverElement, productOptionType){
    var addButton = {
        buttonID:"addNowButton",
        buttonText:"Add Now",
        buttonAction:function (popupMenuOuter, popupMenuSettings) {
            generateDialog(enterCustomerInfoDialogGenerationJSON);
        }
    };
    var addToCartButton = {
        buttonID:"addToCartbutton",
        buttonText:"Add to Cart",
        buttonAction:function (popupMenuOuter, popupMenuSettings) {
//                //add the list item to the shopping cart list
//                var clone = targetEl.parent().parent().parent().clone();
//                $("#shoppingCartTile .tileListView").append(clone);
//                //set the click listener of the shopping car tile button to jump into the add workflow
//                $("#shoppingCartTile ul li .ui-btn-text").click(function () {
//                    $.mobile.changePage('#enterCustomerInformationDialog', {changeHash:'false', transition:'fade', role:'dialog', reverse:false});
//                });
            console.log("hello");
        }
    };
    var addReferralButton = {
        buttonID:"addReferralButton",
        buttonText:"Add Referral",
        buttonAction:function (popupMenuOuter, popupMenuSettings) {
            generateDialog(addReferralDialogGenerationJSON);
        }
    };
    var notInterestedButton = {
        buttonID:"notInterestedButton",
        buttonText:"Not Interested",
        buttonAction:function (popupMenuOuter, popupMenuSettings) {
            //remove the list item from the product options tile
            //targetEl.parent().parent().parent().remove(); Removal is apparently handled by host (CrossSell), uncomment if this changes
            console.log("goodbye");
        }
    };

    var actionMenuSettings = {
        //formatting for the popup menu
        formatting:{
            width:190,
            height:200,
            margins:3,
            optionsToDisplay:4
        },
        //function to call on open
        onOpen:function () {
            //alert("open");
        },
        //function to call on close
        onClose:function () {
            //alert("close");
        },
        //the function(s) to call along with specific button functionality
        baseFunction:function (popupMenuOuter, popupMenuSettings) {
            //$(popupMenuOuter).popup('close');
        },
        //The css class that is to be assign to all list elements
        elementClass:"popupMenuButton",
        //list of elements in the popup menu
        elementList:new Array()
    };

    if(productOptionType!=null && productOptionType.length>0){
        if(productOptionType=="checking/savings"){
            actionMenuSettings.elementList.push(addButton);
            actionMenuSettings.elementList.push(addToCartButton);
            actionMenuSettings.elementList.push(addReferralButton);
            actionMenuSettings.elementList.push(notInterestedButton);
        }else{
            actionMenuSettings.elementList.push(notInterestedButton);
        }
    }else{
        console.log("Invalid product option type given");
    }

    $(hoverElement).createMenu(actionMenuSettings);
}