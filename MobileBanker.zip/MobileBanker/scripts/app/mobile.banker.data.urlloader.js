
var urls=[
	          "pages/CustomerSearchDialog.html",
	          "pages/CustomerSearchResultsDialog.html"
          ];

/**
 * Uses simple JQuery ajax calls to load the html dialogs and pages into the DOM
 * @param urlAddress
 */
function loadDialog(urlAddress){
	//$.mobile.loadPage(urlAddress);
	//incLoadIndex();
	$.ajax({
	    url: urlAddress,
	    success: function (data) {
	    	$('body').append(data);
	    	incLoadIndex();
	    },
	    dataType: 'html'
	});
}//end loadDialog

/**
 * Loads all of the URLs into the DOM by initializing a collection of URLs and fetching data from the server.
 * Next a URLView is created and rendered, causing the AJAX calls to be made to load each of the individual URLs.
 */
function loadAll(){
	for(var i = 0, len = urls.length; i<len; i++ ){
		loadDialog(urls[i]);
	}
}//end loadAllUrls()

